# Halfway Famous — Agency Website

Marketing site for **Halfway Famous**, an independent creative and performance agency.
Built with **Next.js 15 (App Router) · React 19 · TypeScript · Tailwind CSS v4 · Motion**.

> Status: production-ready codebase with draft copy and clearly labeled placeholders.
> Not deployed. See `PLACEHOLDERS.md` before launch.

---

## Quick start

```bash
# Node 20+ (tested on Node 22)
npm install
npm run dev          # http://localhost:3000
```

| Command         | What it does                                  |
| --------------- | --------------------------------------------- |
| `npm run dev`   | Local dev server with hot reload              |
| `npm run build` | Production build (type-checks + static export of all pages) |
| `npm run start` | Serve the production build                    |
| `npm run lint`  | TypeScript check (`tsc --noEmit`)             |

Copy `.env.example` to `.env.local` and set `NEXT_PUBLIC_SITE_URL` to the real domain (used for canonical URLs, sitemap and Open Graph).

---

## Project structure

```
app/
  layout.tsx              Root layout: fonts, metadata, header/footer, JSON-LD
  template.tsx            Page transition (vermilion curtain on route change)
  globals.css             Design tokens (Tailwind @theme) + type utilities
  page.tsx                Home
  work/page.tsx           Work index (filterable)
  work/[slug]/page.tsx    Case study template (static params)
  services/page.tsx       Services detail
  about/page.tsx          About
  insights/page.tsx       Insights index
  insights/[slug]/page.tsx Article template
  contact/page.tsx        Contact + form
  api/contact/route.ts    Contact form endpoint (validates; wire to email/CRM)
  privacy/page.tsx        Privacy placeholder
  not-found.tsx           404
  sitemap.ts, robots.ts, icon.svg, opengraph-image.tsx   SEO
  fonts/                  Self-hosted Space Grotesk + Inter (OFL)
components/
  Header.tsx, Footer.tsx, Logo.tsx, PageHero.tsx, ContactCTA.tsx
  Reveal.tsx              Reveal + SplitText motion primitives
  ui.tsx                  ButtonLink, ArrowLink, SectionLabel, PlaceholderTag, Marquee
  ArtPlate.tsx            Original generative placeholder artwork (SVG)
  WorkPanel.tsx, WorkIndex.tsx, ParallaxPlate.tsx, HorizonRule.tsx, ContactForm.tsx
  home/                   Hero, Manifesto, FeaturedWork, ServicesList, Philosophy, Process, Credibility
lib/
  content.ts              ALL site copy & data (projects, services, insights, principles)
  mark.ts                 Logo mark SVG path
public/brand/             Original logo PNG + mark SVG
```

## Editing content

Almost everything lives in **`lib/content.ts`**:

- `site` — email, phone, location, social links
- `projects` — case studies (add/remove objects; pages generate automatically)
- `services`, `processSteps`, `principles`, `insights`

Page-specific copy (hero lines, section headings) is in each `app/**/page.tsx` or `components/home/*`.
Headlines use `SplitText`: each array item is a line, and `*word*` renders that word in vermilion.

### Replacing placeholder imagery

Placeholder visuals are `<ArtPlate variant="…" />` SVG compositions. To use real photography or film:

1. Add files to `public/work/…`
2. Replace `<ArtPlate …/>` in `WorkPanel.tsx`, `ParallaxPlate.tsx` and the case-study gallery with `next/image`
   (`<Image src="/work/x.jpg" alt="…" fill sizes="(min-width:768px) 60vw, 100vw" className="object-cover" />`).
3. Optionally add an `image` field to `Project` in `lib/content.ts`.

### Client logos / testimonials / metrics

`components/home/Credibility.tsx` contains empty, labeled frames. Only add genuine, approved material.

## Contact form

`app/api/contact/route.ts` validates submissions (required fields, email format, honeypot) and logs them.
Before launch, connect a delivery method, e.g.:

- **Resend / Postmark** – send an email with the payload (store the API key in env vars)
- **HubSpot / other CRM** – POST to their forms API
- **Slack / Zapier webhook** – set `CONTACT_WEBHOOK_URL` and uncomment the example

## Deploying (when approved)

Nothing has been deployed. Recommended: **Vercel** (zero-config for Next.js).

1. Push this folder to a Git repo (GitHub/GitLab).
2. Import it in Vercel → Framework: Next.js (auto-detected).
3. Add env vars: `NEXT_PUBLIC_SITE_URL` (+ any contact-form keys).
4. Add the custom domain and deploy.

Any Node 20+ host also works: `npm ci && npm run build && npm run start` (port 3000).
Netlify and Cloudflare Pages work via their Next.js adapters.

## Accessibility & performance notes

- Respects `prefers-reduced-motion` (Motion `reducedMotion="user"` + CSS overrides; timecode/grain pause).
- Skip link, visible focus rings, `aria-expanded`/`aria-controls` on menu and accordions, focus trap + Escape in mobile menu, header reappears on keyboard focus.
- Hover-only reveals have touch equivalents (work details are always visible on mobile; services use tap-to-expand).
- All pages are statically generated; fonts are self-hosted (no third-party requests); placeholder art is inline SVG (no image weight).
- Font files had contour overlaps removed (`fonttools`) to prevent hairline artifacts at very large display sizes.

See `DESIGN_SYSTEM.md` for tokens and components and `PLACEHOLDERS.md` for everything that needs real content.
