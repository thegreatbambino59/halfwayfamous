/**
 * Central content source for the Halfway Famous site.
 * Everything wrapped in [square brackets] is a placeholder that needs real agency content.
 * See PLACEHOLDERS.md for the full list.
 */

export const site = {
  name: "Halfway Famous",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.halfwayfamous.com",
  tagline: "Ordinary gets ignored.",
  description:
    "Halfway Famous is an independent creative and performance marketing agency. Strategy, brand, advertising, web and AI automation for companies that would rather be remembered than merely seen.",
  email: "hello@halfwayfamous.com", // PLACEHOLDER: confirm inbox
  phone: "[+1 (000) 000-0000]", // PLACEHOLDER
  location: "Lehi, Utah", // PLACEHOLDER: confirm public location
  social: [
    { label: "Instagram", href: "#" },
    { label: "LinkedIn", href: "#" },
    { label: "X", href: "#" },
    { label: "YouTube", href: "#" },
  ],
};

export const nav = [
  { label: "Work", href: "/work" },
  { label: "Services", href: "/services" },
  { label: "About", href: "/about" },
  { label: "Insights", href: "/insights" },
  { label: "Contact", href: "/contact" },
];

export type ArtVariant = "sun" | "topo" | "halves" | "signal" | "grid" | "orbit";

export type Project = {
  slug: string;
  title: string;
  client: string;
  sector: string;
  year: string;
  disciplines: string[];
  summary: string;
  art: ArtVariant;
  metrics: { value: string; label: string }[];
  challenge: string;
  idea: string;
  execution: string[];
  outcome: string;
};

/** Example projects — layout placeholders only. Replace with genuine client work. */
export const projects: Project[] = [
  {
    slug: "the-loudest-quiet-coffee",
    title: "The Loudest Quiet Coffee",
    client: "[Client name]",
    sector: "Specialty coffee roaster",
    year: "[Year]",
    disciplines: ["Brand & Creative", "Digital Advertising"],
    summary:
      "A small-batch roaster competing with chains on volume. We stopped shouting about beans and started a cult around patience.",
    art: "sun",
    metrics: [
      { value: "+00%", label: "[Repeat purchase rate]" },
      { value: "0.0×", label: "[Return on ad spend]" },
    ],
    challenge:
      "Every coffee brand on the shelf claims the same three things: ethical, artisanal, bold. The roaster had a better product and a smaller budget, and their advertising looked like everyone else's.",
    idea:
      "Slow is the feature. We built the brand around the 14 hours each batch takes, turning the wait into the story: limited drops, a countdown subscription, and packaging that tells you exactly when your beans were roasted.",
    execution: [
      "Brand platform, naming system and packaging refresh",
      "Paid social launch built on short, unhurried film cuts",
      "Subscription landing page with drop-based scarcity",
      "Lifecycle email series timed to each roast window",
    ],
    outcome:
      "[Describe the real outcome here once this is replaced with a genuine engagement. Keep claims specific, verifiable and approved by the client.]",
  },
  {
    slug: "off-the-map",
    title: "Off the Map",
    client: "[Client name]",
    sector: "Outdoor gear retailer",
    year: "[Year]",
    disciplines: ["Web Design & Development", "Digital Advertising"],
    summary:
      "An e-commerce relaunch for people who don't follow trails. Topographic design language, a faster store and campaigns that feel like dispatches from the field.",
    art: "topo",
    metrics: [
      { value: "+00%", label: "[Conversion rate]" },
      { value: "−00%", label: "[Customer acquisition cost]" },
    ],
    challenge:
      "A loyal but aging customer base, a slow storefront and paid campaigns that were getting more expensive every quarter.",
    idea:
      "Treat the store like a map, not a catalog. Products are organized by where you're going, not what they are, and every ad is a postcard from somewhere hard to reach.",
    execution: [
      "Shopify rebuild with destination-led navigation",
      "Topographic visual system and photography direction",
      "Full-funnel Meta and Google program with creative testing cadence",
      "Post-purchase flows that recommend the next trip, not just the next product",
    ],
    outcome:
      "[Describe the real outcome here once this is replaced with a genuine engagement.]",
  },
  {
    slug: "the-clinic-that-called-back",
    title: "The Clinic That Called Back",
    client: "[Client name]",
    sector: "Regional health clinic",
    year: "[Year]",
    disciplines: ["Strategy & Consulting", "AI & Automation"],
    summary:
      "Patients were lost between the ad click and the front desk. We built an automated follow-up system that made a busy clinic feel personal again.",
    art: "halves",
    metrics: [
      { value: "00%", label: "[Lead response time reduction]" },
      { value: "+000", label: "[Booked consultations per month]" },
    ],
    challenge:
      "Strong demand, weak follow-through. Inquiries came in after hours, sat unanswered and quietly went to competitors.",
    idea:
      "Speed is a form of care. A clinic that replies in minutes feels like a clinic that listens, so we designed the system around the first five minutes after someone reaches out.",
    execution: [
      "Lead journey audit and attribution model",
      "AI-assisted intake and instant, human-reviewed follow-up",
      "CRM automation with front-desk handoff rules",
      "Local search and paid campaigns rebuilt around booked visits",
    ],
    outcome:
      "[Describe the real outcome here once this is replaced with a genuine engagement.]",
  },
  {
    slug: "signal-over-noise",
    title: "Signal Over Noise",
    client: "[Client name]",
    sector: "Professional services firm",
    year: "[Year]",
    disciplines: ["Strategy & Consulting", "Brand & Creative"],
    summary:
      "A respected firm that sounded like every competitor. A sharper position, a braver voice and a thought-leadership engine with a point of view.",
    art: "signal",
    metrics: [
      { value: "+00%", label: "[Qualified inbound leads]" },
      { value: "00", label: "[Earned media placements]" },
    ],
    challenge:
      "Decades of expertise, buried under a website and a voice built to offend nobody.",
    idea:
      "Say the thing competitors are thinking but won't put in writing. The brand now leads with opinions and backs them with data.",
    execution: [
      "Positioning workshops and messaging architecture",
      "Verbal identity and editorial guidelines",
      "Content program with founder-led video",
      "LinkedIn advertising aimed at decision makers",
    ],
    outcome:
      "[Describe the real outcome here once this is replaced with a genuine engagement.]",
  },
  {
    slug: "built-to-be-found",
    title: "Built to Be Found",
    client: "[Client name]",
    sector: "Home services company",
    year: "[Year]",
    disciplines: ["Web Design & Development", "Digital Advertising"],
    summary:
      "A fast, local-first website and search program for a company whose customers only look for them when something breaks.",
    art: "grid",
    metrics: [
      { value: "+00%", label: "[Calls from search]" },
      { value: "0.0s", label: "[Page load time]" },
    ],
    challenge:
      "Customers search in a panic and call the first credible result. The company wasn't that result.",
    idea:
      "Be the calmest thing on the screen. Clear prices, real photos of real technicians and one tap to call.",
    execution: [
      "Performance-first website rebuild",
      "Service-area pages and local search program",
      "Call-tracking and lead quality scoring",
      "Search ads tuned by hour, weather and season",
    ],
    outcome:
      "[Describe the real outcome here once this is replaced with a genuine engagement.]",
  },
  {
    slug: "the-autopilot-myth",
    title: "The Autopilot Myth",
    client: "[Client name]",
    sector: "Online education brand",
    year: "[Year]",
    disciplines: ["AI & Automation", "Strategy & Consulting"],
    summary:
      "Automation that sounds like a person. A content and nurture system that scaled a founder's voice without sanding it down.",
    art: "orbit",
    metrics: [
      { value: "00 hrs", label: "[Hours saved per week]" },
      { value: "+00%", label: "[Webinar show-up rate]" },
    ],
    challenge:
      "A founder-led brand where everything depended on one person's time and voice.",
    idea:
      "Use AI as an editor, not an author. Systems draft, people decide, and the voice stays human.",
    execution: [
      "Workflow audit and automation roadmap",
      "Voice-trained content drafting with human review",
      "Webinar funnel and reminder sequences",
      "Reporting dashboard for the team that actually uses it",
    ],
    outcome:
      "[Describe the real outcome here once this is replaced with a genuine engagement.]",
  },
];

export type Service = {
  id: string;
  name: string;
  short: string;
  description: string;
  deliverables: string[];
  measure: string;
};

export const services: Service[] = [
  {
    id: "strategy",
    name: "Strategy & Consulting",
    short: "Know where you're going before you spend a dollar getting there.",
    description:
      "Positioning, audience insight, go-to-market planning and growth roadmaps. We find the uncomfortable truth about your market and turn it into a plan your whole team can act on.",
    deliverables: [
      "Brand and market positioning",
      "Audience research and personas",
      "Go-to-market and launch plans",
      "Funnel and customer journey audits",
      "Fractional CMO advisory",
    ],
    measure: "Clarity your team can repeat, and a roadmap tied to revenue.",
  },
  {
    id: "brand",
    name: "Brand & Creative",
    short: "Identity, voice and ideas that people actually remember.",
    description:
      "Naming, identity systems, campaigns, content and art direction. We build brands with a point of view and creative that earns attention instead of renting it.",
    deliverables: [
      "Naming and verbal identity",
      "Logo and visual identity systems",
      "Campaign concepts and art direction",
      "Video, photo and motion production",
      "Packaging and brand guidelines",
    ],
    measure: "Distinctiveness, recall and creative that performs in-channel.",
  },
  {
    id: "advertising",
    name: "Digital Advertising",
    short: "Performance media with an actual idea behind it.",
    description:
      "Paid social, search, video and programmatic. Strategy, creative and media buying under one roof, with a testing culture that learns every week.",
    deliverables: [
      "Meta, Google, YouTube and TikTok campaigns",
      "Creative testing frameworks",
      "Landing pages and conversion optimization",
      "Attribution and analytics setup",
      "Email and SMS lifecycle programs",
    ],
    measure: "Customer acquisition cost, return on ad spend and lifetime value.",
  },
  {
    id: "web",
    name: "Web Design & Development",
    short: "Fast, beautiful websites built to convert.",
    description:
      "Marketing sites, e-commerce and landing experiences. Designed with editorial ambition, built with modern engineering and optimized for speed, search and sales.",
    deliverables: [
      "Website strategy and UX architecture",
      "UI design and design systems",
      "Next.js, Webflow and Shopify builds",
      "Technical SEO and performance",
      "CMS setup and team training",
    ],
    measure: "Conversion rate, speed, search visibility and ease of editing.",
  },
  {
    id: "ai",
    name: "AI & Automation",
    short: "Systems that do the busywork so your people can do the brilliant work.",
    description:
      "Practical AI and marketing automation: lead handling, content workflows, CRM orchestration and reporting. Useful, human-reviewed and built around your team.",
    deliverables: [
      "AI readiness and workflow audits",
      "Lead intake and follow-up automation",
      "AI-assisted content operations",
      "CRM and marketing automation builds",
      "Dashboards and reporting",
    ],
    measure: "Hours saved, response time and pipeline that doesn't leak.",
  },
];

export const processSteps = [
  {
    step: "Discover",
    copy: "We dig into your business, your audience and your numbers until we find the insight everyone else missed.",
    detail: "Research · Audits · Workshops",
  },
  {
    step: "Create",
    copy: "Strategy becomes ideas. Ideas become brands, campaigns, websites and systems worth talking about.",
    detail: "Concepts · Design · Production",
  },
  {
    step: "Launch",
    copy: "We ship with intent: tested, tracked and timed so the first impression actually lands.",
    detail: "Build · QA · Go-live",
  },
  {
    step: "Optimize",
    copy: "Then we keep going. Every week we learn, refine and push results further than launch day.",
    detail: "Testing · Reporting · Iteration",
  },
];

export type Insight = {
  slug: string;
  title: string;
  category: string;
  date: string;
  readTime: string;
  excerpt: string;
  body: string[];
};

/** Draft articles. Review, edit and date before publishing. */
export const insights: Insight[] = [
  {
    slug: "ordinary-is-the-most-expensive-strategy",
    title: "Ordinary is the most expensive strategy you can buy",
    category: "Brand",
    date: "[Publish date]",
    readTime: "5 min read",
    excerpt:
      "Playing it safe feels cheap. Then you look at what it costs to make forgettable work visible.",
    body: [
      "Every marketing budget has a hidden line item: the cost of being forgettable. When creative blends in, media has to work harder. You pay for more impressions to get the same recall, more clicks to get the same sale, and more discounts to get the same loyalty.",
      "Safe work feels responsible in the meeting. It survives every round of feedback because nobody can object to it. But nobody can remember it either, and the market doesn't grade on effort.",
      "Distinctive brands get a compounding advantage. People notice them faster, recognize them sooner and share them for free. That isn't an art-school argument. It's an efficiency argument.",
      "The fix isn't to be loud for the sake of it. It's to be specific: a clear idea, a recognizable look and a voice that sounds like somebody. Specific is memorable. Memorable is cheaper.",
    ],
  },
  {
    slug: "ai-should-be-your-editor-not-your-author",
    title: "AI should be your editor, not your author",
    category: "AI & Automation",
    date: "[Publish date]",
    readTime: "6 min read",
    excerpt:
      "The brands winning with AI aren't publishing more. They're deciding faster.",
    body: [
      "The first wave of AI marketing produced a flood of content that all sounded the same, because it was. The models were trained on the average, and average is what came out.",
      "The useful question isn't “what can AI write for us?” It's “what decisions slow us down, and what work keeps our best people from making them?”",
      "In practice, that means automating intake, research, first drafts, reporting and follow-up, then putting a human with taste at every point where the brand speaks.",
      "Speed is the benefit. Judgment is the moat. Build systems that give you more of the first without giving away the second.",
    ],
  },
  {
    slug: "your-ad-account-is-a-creative-problem",
    title: "Your ad account is a creative problem",
    category: "Advertising",
    date: "[Publish date]",
    readTime: "4 min read",
    excerpt:
      "Targeting got automated. Creative is the last real lever, so why is it still an afterthought?",
    body: [
      "Ad platforms now handle most of what media buyers used to do by hand: audiences, bids and placements. The algorithm is good at finding people. It can't make them care.",
      "That leaves creative as the biggest variable in performance, and most brands still treat it as a production task at the end of a media plan.",
      "Flip it. Build a creative testing cadence with clear hypotheses about hooks, formats, offers and angles. Ship weekly. Kill quickly. Scale what works.",
      "Treat every ad as an experiment and every result as a brief for the next round. That's how performance marketing becomes a learning machine.",
    ],
  },
  {
    slug: "the-website-is-the-pitch",
    title: "Your website is the pitch you're not in the room for",
    category: "Web",
    date: "[Publish date]",
    readTime: "5 min read",
    excerpt:
      "Most buyers decide before they talk to you. Your site is doing the selling, or the losing.",
    body: [
      "By the time a prospect fills in a form, they've usually made most of their decision. They've read your site, compared you to two competitors and decided whether you look like the safe choice or the smart one.",
      "That makes your website a sales asset, not a brochure. Every page should answer a question a buyer actually has, in the order they have it.",
      "Speed matters. Clarity matters more. Personality is what makes them remember which tab was yours.",
      "Design the site the way you'd run the meeting: lead with the problem, prove you understand it, show the work and make the next step obvious.",
    ],
  },
];

export const principles = [
  {
    title: "Interesting beats loud.",
    copy: "Volume is easy to buy. Interest has to be earned. We go after the second.",
  },
  {
    title: "Creative is a growth lever.",
    copy: "Ideas and performance aren't separate departments here. The best-performing work is usually the most original.",
  },
  {
    title: "Say less, mean more.",
    copy: "Clear thinking makes clear work. We cut until what's left is impossible to misunderstand.",
  },
  {
    title: "Proof over promises.",
    copy: "We measure what matters, report it plainly and never dress up a number.",
  },
  {
    title: "Keep going.",
    copy: "Halfway is a direction, not a destination. Launch day is the start of the work.",
  },
];
