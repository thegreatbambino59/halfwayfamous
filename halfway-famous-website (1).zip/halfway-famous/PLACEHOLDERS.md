# Placeholders: replace before launch

Everything below is draft or placeholder content. Nothing on the site claims real clients, results or testimonials.

## Business details: `lib/content.ts → site`
- [ ] Contact email (`hello@halfwayfamous.com` assumed)
- [ ] Phone number (`[+1 (000) 000-0000]`)
- [ ] Public location (`Lehi, Utah`): confirm or change
- [ ] Social profile URLs (Instagram, LinkedIn, X, YouTube currently `#`)
- [ ] Production domain (`NEXT_PUBLIC_SITE_URL`)

## Work: `lib/content.ts → projects`
- [ ] All six projects are **illustrative examples** with no client names (`[Client name]`, `[Year]`)
- [ ] Metrics are placeholders (`+00%`, `[Conversion rate]` etc.)
- [ ] `outcome` text on each case study
- [ ] Project imagery (currently generative SVG `ArtPlate`s labeled "Placeholder visual")
- [ ] Remove the "Example project" / "Example case study" tags once real work is in

## Credibility: `components/home/Credibility.tsx`
- [ ] 8 client logo slots
- [ ] Testimonial quote + name, title, company (approved, verbatim)
- [ ] 3 metric slots (`[Projects launched]`, `[Client ad spend managed]`, `[Average client tenure]`): verified figures only

## About: `app/about/page.tsx`
- [ ] Founder bio (draft for Lance Duffin, please review)
- [ ] Founder portrait
- [ ] 3 team member slots: names, roles, bios, portraits (or remove)
- [ ] "The mark" copy explains the split mark and mirrored F. Confirm it matches the intended meaning
- [ ] Optional: add credentials or notable collaborations you want public

## Insights: `lib/content.ts → insights`
- [ ] 4 draft articles: review, edit, add author names and publish dates
- [ ] Remove "Draft" tags when published

## Contact: `app/contact/page.tsx`, `app/api/contact/route.ts`
- [ ] Connect form delivery (email/CRM/webhook); it currently only validates and logs
- [ ] Confirm the response-time promise ("within two business days") and the 30-minute call process
- [ ] Confirm budget ranges

## Services: `lib/content.ts → services`, `app/services/page.tsx`
- [ ] Review deliverables lists and platforms named (Next.js, Webflow, Shopify, Meta, Google, YouTube, TikTok)
- [ ] Review the engagement models (Projects / Retainers / Advisory)

## Legal & SEO
- [ ] Privacy policy (placeholder page at `/privacy`, have it reviewed)
- [ ] Cookie consent if analytics/pixels are added
- [ ] Analytics (none installed)
- [ ] Review the Open Graph image (`app/opengraph-image.tsx`) and favicon (`app/icon.svg`)
