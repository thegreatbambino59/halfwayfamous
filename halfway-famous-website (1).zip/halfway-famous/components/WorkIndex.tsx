"use client";

import { AnimatePresence, LayoutGroup, motion } from "motion/react";
import { useState } from "react";
import { projects, services } from "@/lib/content";
import { WorkPanel } from "./WorkPanel";
import { EASE } from "./Reveal";
import { cn } from "@/lib/cn";

const layouts = [
  { col: "md:col-span-7", aspect: "aspect-[4/3]" },
  { col: "md:col-span-5 md:mt-40", aspect: "aspect-[4/5]" },
  { col: "md:col-span-5", aspect: "aspect-[4/5]" },
  { col: "md:col-span-7 md:mt-40", aspect: "aspect-[4/3]" },
];

export function WorkIndex() {
  const [filter, setFilter] = useState<string>("All");
  const filters = ["All", ...services.map((s) => s.name)];
  const list = filter === "All" ? projects : projects.filter((p) => p.disciplines.includes(filter));

  return (
    <section className="bg-paper text-ink" aria-label="Projects">
      <div className="gutter section-y">
        <div role="group" aria-label="Filter projects by discipline" className="-mx-1 flex flex-wrap gap-2">
          {filters.map((f) => (
            <button
              key={f}
              type="button"
              aria-pressed={filter === f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-full border px-4 py-2 font-display text-sm font-medium transition-colors duration-300",
                filter === f
                  ? "border-ink bg-ink text-paper"
                  : "border-ink/20 text-ink/70 hover:border-ink hover:text-ink",
              )}
            >
              {f}
              {f !== "All" && (
                <span className="ml-1.5 text-xs opacity-50">
                  {projects.filter((p) => p.disciplines.includes(f)).length}
                </span>
              )}
            </button>
          ))}
        </div>
        <p className="mt-6 text-sm text-ink/55" aria-live="polite">
          Showing {list.length} example {list.length === 1 ? "project" : "projects"}. All projects shown are illustrative
          placeholders.
        </p>

        <LayoutGroup>
          <motion.ul layout className="mt-14 grid gap-x-10 gap-y-20 md:mt-20 md:grid-cols-12 md:gap-y-28">
            <AnimatePresence mode="popLayout">
              {list.map((p, i) => {
                const l = layouts[i % layouts.length];
                return (
                  <motion.li
                    key={p.slug}
                    layout
                    initial={{ opacity: 0, y: 40 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.96 }}
                    transition={{ duration: 0.8, ease: EASE }}
                    className={l.col}
                  >
                    <WorkPanel project={p} index={projects.indexOf(p)} aspect={l.aspect} />
                  </motion.li>
                );
              })}
            </AnimatePresence>
          </motion.ul>
        </LayoutGroup>
      </div>
    </section>
  );
}
