import type { ReactNode } from "react";
import { Reveal, SplitText } from "./Reveal";
import { HorizonRule } from "./HorizonRule";

/** Shared interior-page hero: eyebrow, oversized split-reveal title, intro and the horizon rule motif. */
export function PageHero({
  eyebrow,
  title,
  intro,
  aside,
}: {
  eyebrow: string;
  title: string[];
  intro?: ReactNode;
  aside?: ReactNode;
}) {
  return (
    <section className="grain relative overflow-hidden bg-ink pt-36 pb-16 text-paper md:pt-48 md:pb-24">
      <div className="gutter relative z-[3]">
        <Reveal y={12}>
          <p className="text-eyebrow mb-8 flex items-center gap-3 text-ash md:mb-12">
            <span className="h-2 w-2 rounded-full bg-vermilion" aria-hidden="true" />
            {eyebrow}
          </p>
        </Reveal>
        <SplitText as="h1" lines={title} className="text-mega" onMount stagger={0.07} delay={0.1} />
        <div className="mt-14 md:mt-20">
          <HorizonRule />
        </div>
        {(intro || aside) && (
          <div className="mt-10 grid gap-10 md:mt-14 md:grid-cols-12">
            {intro && (
              <Reveal className="md:col-span-6" delay={0.3}>
                <div className="text-lede text-paper/80">{intro}</div>
              </Reveal>
            )}
            {aside && (
              <Reveal className="md:col-span-4 md:col-start-9" delay={0.4}>
                {aside}
              </Reveal>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
