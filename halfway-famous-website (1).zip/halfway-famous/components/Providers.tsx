"use client";

import { MotionConfig } from "motion/react";

/** reducedMotion="user" disables transform/layout animations for prefers-reduced-motion users. */
export function Providers({ children }: { children: React.ReactNode }) {
  return <MotionConfig reducedMotion="user">{children}</MotionConfig>;
}
