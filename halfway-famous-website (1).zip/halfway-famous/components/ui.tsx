import Link from "next/link";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function Arrow({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" className={cn("h-[1em] w-[1em]", className)}>
      <path d="M5 19 19 5M8 5h11v11" stroke="currentColor" strokeWidth="1.8" strokeLinecap="square" />
    </svg>
  );
}

type Tone = "vermilion" | "ink" | "paper" | "ghost-light" | "ghost-dark";

const tones: Record<Tone, string> = {
  vermilion: "bg-vermilion text-white [--fill:var(--color-ink)]",
  ink: "bg-ink text-paper [--fill:var(--color-vermilion)]",
  paper: "bg-paper text-ink [--fill:var(--color-vermilion)] hover:text-white",
  "ghost-light": "border border-paper/30 text-paper [--fill:var(--color-paper)] hover:text-ink",
  "ghost-dark": "border border-ink/25 text-ink [--fill:var(--color-ink)] hover:text-paper",
};

/** Pill button with a fill that rises from below on hover. */
export function ButtonLink({
  href,
  children,
  tone = "vermilion",
  size = "md",
  className,
}: {
  href: string;
  children: ReactNode;
  tone?: Tone;
  size?: "md" | "lg";
  className?: string;
}) {
  return (
    <Link
      href={href}
      className={cn(
        "group relative inline-flex items-center gap-3 overflow-hidden rounded-full font-display font-medium tracking-tight transition-colors duration-500",
        size === "lg" ? "px-8 py-5 text-lg md:px-10 md:py-6 md:text-xl" : "px-6 py-3.5 text-[0.95rem]",
        tones[tone],
        className,
      )}
    >
      <span
        aria-hidden="true"
        className="absolute inset-0 translate-y-full rounded-full bg-[var(--fill)] transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-y-0 group-focus-visible:translate-y-0"
      />
      <span className="relative">{children}</span>
      <span className="relative inline-flex overflow-hidden">
        <Arrow className="transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-x-full group-hover:-translate-y-full" />
        <Arrow className="absolute -translate-x-full translate-y-full transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-x-0 group-hover:translate-y-0" />
      </span>
    </Link>
  );
}

/** Underlined text link with arrow. */
export function ArrowLink({ href, children, className }: { href: string; children: ReactNode; className?: string }) {
  return (
    <Link
      href={href}
      className={cn(
        "group inline-flex items-center gap-2 font-display text-[0.95rem] font-medium",
        "bg-[linear-gradient(currentColor,currentColor)] bg-[length:100%_1px] bg-left-bottom bg-no-repeat pb-1",
        "transition-[background-size] duration-500 hover:bg-[length:0%_1px] hover:bg-right-bottom",
        className,
      )}
    >
      {children}
      <Arrow className="transition-transform duration-500 group-hover:rotate-45" />
    </Link>
  );
}

/** Numbered editorial section label, e.g. (02) Selected work */
export function SectionLabel({ index, children, className }: { index?: string; children: ReactNode; className?: string }) {
  return (
    <p className={cn("text-eyebrow flex items-center gap-3", className)}>
      {index && <span className="text-vermilion">({index})</span>}
      <span>{children}</span>
      <span aria-hidden="true" className="h-px w-10 bg-current opacity-40" />
    </p>
  );
}

/** Small honest label for anything that is placeholder content. */
export function PlaceholderTag({ children = "Example project", className }: { children?: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-current/30 px-2.5 py-1 font-display text-[0.65rem] font-medium tracking-[0.14em] uppercase",
        className,
      )}
    >
      <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-vermilion" />
      {children}
    </span>
  );
}

export function Marquee({
  items,
  className,
  duration = 38,
  separator = "✺",
}: {
  items: string[];
  className?: string;
  duration?: number;
  separator?: string;
}) {
  const row = (hidden: boolean) => (
    <div className="flex shrink-0 items-center" aria-hidden={hidden || undefined}>
      {items.map((item, i) => (
        <span key={i} className="flex items-center">
          <span className="px-6 md:px-10">{item}</span>
          <span className="text-[0.5em] opacity-70" aria-hidden="true">
            {separator}
          </span>
        </span>
      ))}
    </div>
  );
  return (
    <div className={cn("marquee overflow-hidden whitespace-nowrap", className)}>
      <div className="marquee-track flex w-max" style={{ ["--marquee-duration" as string]: `${duration}s` }}>
        {row(false)}
        {row(true)}
      </div>
    </div>
  );
}
