"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { Logo } from "./Logo";
import { nav, site } from "@/lib/content";
import { cn } from "@/lib/cn";
import { EASE } from "./Reveal";

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [solid, setSolid] = useState(false);
  const { scrollY } = useScroll();
  const toggleRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useMotionValueEvent(scrollY, "change", (y) => {
    const prev = scrollY.getPrevious() ?? 0;
    setSolid(y > 40);
    setHidden(y > 240 && y > prev && !open);
  });

  // Close on route change
  useEffect(() => setOpen(false), [pathname]);

  // Lock scroll, handle Escape + simple focus trap while menu is open
  useEffect(() => {
    if (!open) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const first = menuRef.current?.querySelector<HTMLElement>("a");
    first?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
      if (e.key === "Tab" && menuRef.current) {
        const items = [toggleRef.current, ...menuRef.current.querySelectorAll<HTMLElement>("a")].filter(
          Boolean,
        ) as HTMLElement[];
        const idx = items.indexOf(document.activeElement as HTMLElement);
        if (e.shiftKey && idx <= 0) {
          e.preventDefault();
          items[items.length - 1].focus();
        } else if (!e.shiftKey && idx === items.length - 1) {
          e.preventDefault();
          items[0].focus();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + "/");

  return (
    <>
      <a
        href="#main"
        className="fixed top-3 left-3 z-[100] -translate-y-20 rounded-full bg-vermilion px-4 py-2 text-sm text-white focus:translate-y-0"
      >
        Skip to content
      </a>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-[transform,background-color,backdrop-filter] duration-500 ease-[var(--ease-expo)]",
          hidden ? "-translate-y-full focus-within:translate-y-0" : "translate-y-0",
          solid && !open ? "bg-ink/85 backdrop-blur-md" : "bg-transparent",
        )}
      >
        <div className="gutter flex h-16 items-center justify-between text-paper md:h-20">
          <Link href="/" aria-label="Halfway Famous — home" className="relative z-[60]">
            <Logo />
          </Link>

          <nav aria-label="Primary" className="hidden md:block">
            <ul className="flex items-center gap-1">
              {nav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={isActive(item.href) ? "page" : undefined}
                    className={cn(
                      "group relative flex items-center gap-2 rounded-full px-4 py-2 font-display text-[0.92rem] font-medium transition-colors",
                      item.label === "Contact"
                        ? "ml-3 bg-paper text-ink hover:bg-vermilion hover:text-white"
                        : "text-paper/80 hover:text-paper",
                    )}
                  >
                    {item.label !== "Contact" && (
                      <span
                        aria-hidden="true"
                        className={cn(
                          "h-1.5 w-1.5 rounded-full bg-vermilion transition-transform duration-300",
                          isActive(item.href) ? "scale-100" : "scale-0 group-hover:scale-100",
                        )}
                      />
                    )}
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <button
            ref={toggleRef}
            type="button"
            className="relative z-[60] flex h-11 items-center gap-3 rounded-full pr-1 pl-4 font-display text-sm font-medium md:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((v) => !v)}
          >
            <span>{open ? "Close" : "Menu"}</span>
            <span className="relative flex h-10 w-10 items-center justify-center rounded-full bg-paper text-ink">
              <span
                className={cn(
                  "absolute h-[1.5px] w-4 bg-current transition-transform duration-500 ease-[var(--ease-expo)]",
                  open ? "rotate-45" : "-translate-y-[3px]",
                )}
              />
              <span
                className={cn(
                  "absolute h-[1.5px] w-4 bg-current transition-transform duration-500 ease-[var(--ease-expo)]",
                  open ? "-rotate-45" : "translate-y-[3px]",
                )}
              />
            </span>
          </button>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            ref={menuRef}
            role="dialog"
            aria-modal="true"
            aria-label="Site menu"
            className="fixed inset-0 z-40 flex flex-col bg-ink text-paper md:hidden"
            initial={{ clipPath: "inset(0 0 100% 0)" }}
            animate={{ clipPath: "inset(0 0 0% 0)" }}
            exit={{ clipPath: "inset(0 0 100% 0)" }}
            transition={{ duration: 0.7, ease: [0.76, 0, 0.24, 1] }}
          >
            <nav aria-label="Mobile" className="gutter flex flex-1 flex-col justify-center pt-20">
              <ul className="space-y-1">
                {[{ label: "Home", href: "/" }, ...nav].map((item, i) => (
                  <li key={item.href} className="overflow-hidden">
                    <motion.div
                      initial={{ y: "100%" }}
                      animate={{ y: 0 }}
                      transition={{ duration: 0.8, ease: EASE, delay: 0.25 + i * 0.06 }}
                    >
                      <Link
                        href={item.href}
                        aria-current={pathname === item.href ? "page" : undefined}
                        className="flex items-baseline gap-4 py-1 font-display text-[clamp(2.6rem,13vw,4.5rem)] leading-[1] font-bold tracking-[-0.045em]"
                      >
                        <span className="w-6 font-sans text-xs font-normal tracking-normal text-ash">0{i + 1}</span>
                        <span className={cn(pathname === item.href && "text-vermilion")}>{item.label}</span>
                      </Link>
                    </motion.div>
                  </li>
                ))}
              </ul>
            </nav>
            <motion.div
              className="gutter flex items-end justify-between border-t border-paper/10 py-6 text-sm text-ash"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              <a href={`mailto:${site.email}`} className="text-paper">
                {site.email}
              </a>
              <span>{site.location}</span>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
