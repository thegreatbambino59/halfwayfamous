"use client";

import { motion } from "motion/react";
import { EASE } from "./Reveal";

/** Brand motif: a horizon line with a half-sun resting on it. */
export function HorizonRule({ tone = "light" }: { tone?: "light" | "dark" }) {
  const line = tone === "light" ? "bg-paper/30" : "bg-ink/25";
  return (
    <div className="relative h-8" aria-hidden="true">
      <motion.span
        className={`absolute inset-x-0 bottom-0 h-px origin-left ${line}`}
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1.6, ease: EASE }}
      />
      <motion.span
        className="absolute right-[8%] bottom-0 block h-8 w-16 overflow-hidden"
        initial={{ opacity: 0, y: 12 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1.2, ease: EASE, delay: 0.8 }}
      >
        <span className="absolute inset-x-0 top-0 h-16 rounded-full bg-vermilion" />
      </motion.span>
    </div>
  );
}
