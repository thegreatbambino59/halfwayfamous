import { LogoMark } from "./Logo";
import { SplitText } from "./Reveal";
import { ButtonLink } from "./ui";
import { site } from "@/lib/content";

/** Full-bleed vermilion closing call to action. Reused on every page. */
export function ContactCTA({
  lines = ["LET'S MAKE", "SOME NOISE."],
  copy = "Got a brand that deserves more attention than it's getting? Tell us what you're building. We'll tell you how to make people care.",
}: {
  lines?: string[];
  copy?: string;
}) {
  return (
    <section className="grain relative overflow-hidden bg-vermilion text-ink" aria-labelledby="cta-heading">
      <LogoMark className="pointer-events-none absolute -right-[12vw] -bottom-[18vw] h-[62vw] w-[62vw] rotate-[-8deg] text-ink/[0.07] md:-right-[6vw] md:h-[46vw] md:w-[46vw]" />
      <div className="gutter section-y relative z-[3]">
        <p className="text-eyebrow mb-8 flex items-center gap-3 md:mb-12">
          <span className="h-2 w-2 rounded-full bg-ink" aria-hidden="true" />
          Now booking new projects
        </p>
        <div id="cta-heading">
          <SplitText as="h2" lines={lines} className="text-mega" stagger={0.08} accentClassName="text-paper" />
        </div>
        <div className="mt-12 grid gap-10 md:mt-16 md:grid-cols-12 md:items-end">
          <p className="text-lede max-w-xl md:col-span-6">{copy}</p>
          <div className="flex flex-wrap items-center gap-6 md:col-span-6 md:justify-end">
            <ButtonLink href="/contact" tone="ink" size="lg">
              Start a project
            </ButtonLink>
            <a href={`mailto:${site.email}`} className="font-display text-lg font-medium underline decoration-1 underline-offset-[6px] hover:decoration-2">
              {site.email}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
