import { cn } from "@/lib/cn";
import { MARK_D } from "@/lib/mark";

/** The split "half" mark, redrawn as a crisp SVG from the supplied logo. Holes are transparent. */
export const MARK_PATH = MARK_D;

export function LogoMark({ className, title }: { className?: string; title?: string }) {
  return (
    <svg
      viewBox="0 0 274 274"
      className={cn("block", className)}
      role={title ? "img" : undefined}
      aria-hidden={title ? undefined : true}
      aria-label={title}
    >
      <path d={MARK_PATH} fill="currentColor" fillRule="evenodd" />
    </svg>
  );
}

/** HALꟻ — the stacked lockup wordmark with the mirrored F. */
export function HalfWord({ className }: { className?: string }) {
  return (
    <span className={cn("font-display font-bold tracking-[0.42em] [--track:0.42em]", className)} aria-hidden="true">
      HAL<span className="mirror">F</span>
    </span>
  );
}

/** Horizontal lockup used in the header. */
export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-3", className)}>
      <LogoMark className="h-7 w-7 md:h-8 md:w-8" />
      <span aria-hidden="true" className="font-display text-[0.8rem] font-semibold leading-none tracking-[0.22em] uppercase [--track:0.22em] md:text-[0.85rem]">
        Hal<span className="mirror">f</span>way <span className="text-ash">Famous</span>
      </span>
      <span className="sr-only">Halfway Famous</span>
    </span>
  );
}
