"use client";

import {
  motion,
  useMotionValue,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from "motion/react";
import { useEffect, useRef } from "react";
import { ButtonLink } from "../ui";
import { EASE } from "../Reveal";

const lines = ["ORDINARY", "GETS", "IGNORED"];

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const tcRef = useRef<HTMLSpanElement>(null);
  const reduce = useReducedMotion();

  // Scroll-out choreography
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const visualScale = useTransform(scrollYProgress, [0, 1], [1, 1.35]);
  const visualY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "-30%"]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  // Pointer parallax (desktop, motion-safe only)
  const px = useMotionValue(0);
  const py = useMotionValue(0);
  const sx = useSpring(px, { stiffness: 60, damping: 20 });
  const sy = useSpring(py, { stiffness: 60, damping: 20 });
  const topX = useTransform(sx, (v) => v * 28);
  const botX = useTransform(sx, (v) => v * -36);
  const topY = useTransform(sy, (v) => v * 14);
  const botY = useTransform(sy, (v) => v * -10);

  useEffect(() => {
    if (reduce || window.matchMedia("(pointer: coarse)").matches) return;
    const onMove = (e: PointerEvent) => {
      px.set(e.clientX / window.innerWidth - 0.5);
      py.set(e.clientY / window.innerHeight - 0.5);
    };
    window.addEventListener("pointermove", onMove);
    return () => window.removeEventListener("pointermove", onMove);
  }, [px, py, reduce]);

  // Cinematic running timecode (24fps), written straight to the DOM to avoid re-renders
  useEffect(() => {
    if (reduce) return;
    const start = performance.now();
    let raf = 0;
    const pad = (n: number) => String(n).padStart(2, "0");
    const tick = (now: number) => {
      const t = (now - start) / 1000;
      const f = Math.floor((t % 1) * 24);
      const s = Math.floor(t) % 60;
      const m = Math.floor(t / 60) % 60;
      if (tcRef.current) tcRef.current.textContent = `00:${pad(m)}:${pad(s)}:${pad(f)}`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reduce]);

  return (
    <section
      ref={ref}
      className="grain relative flex min-h-[640px] h-[100svh] flex-col overflow-hidden bg-ink text-paper"
      aria-labelledby="hero-title"
    >
      {/* Atmosphere */}
      <div
        aria-hidden="true"
        className="glow-drift pointer-events-none absolute -right-[20%] bottom-[-30%] h-[90vh] w-[90vh] rounded-full bg-[radial-gradient(circle,rgba(228,70,50,0.38),rgba(228,70,50,0)_65%)] blur-2xl"
      />

      {/* The horizon: a sun cut in half — the brand mark, re-imagined as landscape */}
      <motion.div
        aria-hidden="true"
        style={{ scale: visualScale, y: visualY }}
        className="pointer-events-none absolute top-[34%] left-[62%] md:top-[46%] md:left-[71%]"
      >
        <motion.div
          className="absolute top-0 left-[-50vw] h-px w-[200vw] origin-left bg-paper/35"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 1.8, ease: EASE, delay: 0.2 }}
        />
        <div className="relative -translate-x-1/2 [--d:min(92vw,58vh)] md:[--d:min(40vw,70vh)]">
          {/* top half: outline + rings */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.6, ease: EASE, delay: 0.35 }}
            className="absolute bottom-[6px] left-1/2 -translate-x-[46%]"
          >
            <motion.div style={{ x: topX, y: topY }}>
            <svg viewBox="0 0 200 100" className="block h-[calc(var(--d)/2)] w-[var(--d)] overflow-visible">
              {[1.32, 1.18, 1.06].map((s, i) => (
                <path
                  key={s}
                  d={`M${100 - 100 * s} 100a${100 * s} ${100 * s} 0 0 1 ${200 * s} 0`}
                  fill="none"
                  stroke="#F2F0EA"
                  strokeOpacity={0.08 + i * 0.05}
                  strokeWidth="0.35"
                />
              ))}
              <path d="M0 100a100 100 0 0 1 200 0Z" fill="#F2F0EA" fillOpacity="0.06" stroke="#F2F0EA" strokeWidth="0.5" />
            </svg>
            </motion.div>
          </motion.div>
          {/* bottom half: solid vermilion, offset */}
          <motion.div
            initial={{ opacity: 0, y: -40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.6, ease: EASE, delay: 0.5 }}
            className="absolute top-[6px] left-1/2 -translate-x-[56%]"
          >
            <motion.div style={{ x: botX, y: botY }}>
              <svg viewBox="0 0 200 100" className="block h-[calc(var(--d)/2)] w-[var(--d)]">
                <path d="M0 0h200a100 100 0 0 1-200 0Z" fill="#E44632" />
              </svg>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>

      {/* HUD */}
      <div className="gutter relative z-[3] flex items-center justify-between pt-24 text-[0.7rem] tracking-[0.18em] text-ash uppercase md:pt-28">
        <span className="font-display">Independent creative &amp; performance agency</span>
        <span className="hidden items-center gap-2 font-mono md:flex">
          <span className="rec-dot h-2 w-2 rounded-full bg-vermilion" aria-hidden="true" />
          REC <span ref={tcRef}>00:00:00:00</span>
        </span>
      </div>

      {/* Headline + copy */}
      <motion.div style={{ y: textY, opacity: fade }} className="gutter relative z-[3] mt-auto pb-8 md:pb-12">
        <h1 id="hero-title" aria-label="Ordinary gets ignored." className="text-mega">
          {lines.map((line, li) => (
            <span key={line} className="block overflow-hidden pb-[0.04em]" aria-hidden="true">
              <motion.span
                className="inline-block"
                initial={{ y: "105%" }}
                animate={{ y: "0%" }}
                transition={{ duration: 1.2, ease: EASE, delay: 0.15 + li * 0.11 }}
              >
                {line}
                {li === lines.length - 1 && <span className="text-vermilion">.</span>}
              </motion.span>
            </span>
          ))}
        </h1>

        <div className="mt-8 grid gap-8 md:mt-10 md:grid-cols-12 md:items-end">
          <motion.p
            className="text-lede max-w-md text-paper/80 md:col-span-5"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: EASE, delay: 0.75 }}
          >
            Halfway Famous is a creative and performance agency for brands that would rather be remembered than merely
            seen. Sharp strategy, fearless creative, marketing that proves it worked.
          </motion.p>
          <motion.div
            className="flex flex-wrap items-center gap-5 md:col-span-7 md:justify-end"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: EASE, delay: 0.9 }}
          >
            <ButtonLink href="/contact" size="lg">
              Let&apos;s Make Something Happen
            </ButtonLink>
            <a href="#manifesto" className="group hidden items-center gap-3 text-sm text-ash md:flex">
              <span className="relative block h-10 w-px overflow-hidden bg-paper/20">
                <span className="absolute inset-x-0 top-0 h-1/2 animate-[scrollcue_1.8s_ease-in-out_infinite] bg-vermilion" />
              </span>
              Scroll
            </a>
          </motion.div>
        </div>
      </motion.div>

      <style>{`@keyframes scrollcue{0%{transform:translateY(-100%)}100%{transform:translateY(200%)}}`}</style>
    </section>
  );
}
