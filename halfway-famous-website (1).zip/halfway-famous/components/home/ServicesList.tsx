"use client";

import { AnimatePresence, motion } from "motion/react";
import { useId, useState } from "react";
import { services } from "@/lib/content";
import { ArrowLink, SectionLabel } from "../ui";
import { EASE, SplitText } from "../Reveal";
import { cn } from "@/lib/cn";

export function ServicesList() {
  const [open, setOpen] = useState<string | null>(null);
  const baseId = useId();

  return (
    <section className="relative bg-ink text-paper" aria-labelledby="services-title">
      <div className="gutter section-y">
        <div className="mb-16 grid gap-8 md:mb-24 md:grid-cols-12 md:items-end">
          <div className="md:col-span-8">
            <SectionLabel index="03" className="mb-8 text-ash">
              Services
            </SectionLabel>
            <div id="services-title">
              <SplitText as="h2" lines={["Five ways to stop", "being *ignored.*"]} className="text-display" />
            </div>
          </div>
          <p className="text-lede text-paper/70 md:col-span-4">
            One senior team across strategy, creative, media, web and automation. Pick one, or let them work together the
            way they should.
          </p>
        </div>

        <ul className="border-b border-paper/15">
          {services.map((s, i) => {
            const isOpen = open === s.id;
            const panelId = `${baseId}-${s.id}`;
            return (
              <li key={s.id} className="border-t border-paper/15">
                <h3>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    aria-controls={panelId}
                    onClick={() => setOpen(isOpen ? null : s.id)}
                    className="group relative grid w-full grid-cols-[2.5rem_1fr_auto] items-center gap-4 overflow-hidden py-6 text-left md:grid-cols-[5rem_1fr_minmax(0,22rem)_4rem] md:gap-8 md:py-9"
                  >
                    <span
                      aria-hidden="true"
                      className={cn(
                        "absolute inset-0 origin-bottom bg-vermilion transition-transform duration-700 ease-[var(--ease-expo)]",
                        isOpen ? "scale-y-0" : "scale-y-0 group-hover:scale-y-100",
                      )}
                    />
                    <span className={cn("relative font-display text-sm text-ash transition-colors", !isOpen && "group-hover:text-ink")}>
                      0{i + 1}
                    </span>
                    <span
                      className={cn(
                        "relative font-display text-[clamp(2rem,6.4vw,6.25rem)] leading-[0.92] font-bold tracking-[-0.045em] transition-[transform,color] duration-700 ease-[var(--ease-expo)] md:group-hover:translate-x-6",
                        isOpen ? "text-vermilion" : "group-hover:text-ink",
                      )}
                    >
                      {s.name}
                    </span>
                    <span className={cn("relative hidden text-[0.98rem] leading-snug text-paper/60 transition-colors md:block", !isOpen && "group-hover:text-ink")}>
                      {s.short}
                    </span>
                    <span
                      aria-hidden="true"
                      className={cn(
                        "relative flex h-10 w-10 items-center justify-center justify-self-end rounded-full border transition-colors md:h-14 md:w-14",
                        isOpen ? "border-vermilion bg-vermilion text-white" : "border-paper/30 group-hover:border-ink group-hover:text-ink",
                      )}
                    >
                      <span className="absolute h-[1.5px] w-4 bg-current" />
                      <span
                        className={cn(
                          "absolute h-4 w-[1.5px] bg-current transition-transform duration-500",
                          isOpen && "scale-y-0",
                        )}
                      />
                    </span>
                  </button>
                </h3>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={panelId}
                      role="region"
                      aria-label={s.name}
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.7, ease: EASE }}
                      className="overflow-hidden"
                    >
                      <div className="grid gap-10 pb-12 md:grid-cols-[5rem_1fr_1fr_4rem] md:gap-8 md:pb-16">
                        <div className="hidden md:block" />
                        <div>
                          <p className="text-lede max-w-xl text-paper/85">{s.description}</p>
                          <ArrowLink href={`/services#${s.id}`} className="mt-8 text-vermilion">
                            Explore {s.name}
                          </ArrowLink>
                        </div>
                        <ul className="grid gap-0 self-start">
                          {s.deliverables.map((d) => (
                            <li
                              key={d}
                              className="flex items-center gap-3 border-b border-paper/10 py-3 text-[0.98rem] text-paper/80"
                            >
                              <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-vermilion" />
                              {d}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
