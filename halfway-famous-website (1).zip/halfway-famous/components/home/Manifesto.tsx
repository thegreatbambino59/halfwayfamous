"use client";

import { motion, useScroll, useTransform, type MotionValue } from "motion/react";
import { useRef } from "react";
import { Marquee, SectionLabel, ArrowLink } from "../ui";
import { Reveal } from "../Reveal";

const TEXT =
  "Attention is the most expensive thing on earth. Most brands rent it. We'd rather you *earn* it, with ideas sharp enough to cut through, design that refuses to blend in, and marketing that *proves* it worked.";

function Word({ word, progress, range }: { word: string; progress: MotionValue<number>; range: [number, number] }) {
  const opacity = useTransform(progress, range, [0.14, 1]);
  const accent = word.includes("*");
  return (
    <motion.span style={{ opacity }} className={accent ? "text-vermilion italic" : undefined}>
      {word.replace(/\*/g, "")}{" "}
    </motion.span>
  );
}

export function Manifesto() {
  const sectionRef = useRef<HTMLElement>(null);
  const textRef = useRef<HTMLParagraphElement>(null);

  // Dark → light hand-off as the section arrives
  const { scrollYProgress: enter } = useScroll({ target: sectionRef, offset: ["start end", "start 0.25"] });
  const bg = useTransform(enter, [0, 1], ["#111111", "#F2F0EA"]);
  const fg = useTransform(enter, [0, 1], ["#F2F0EA", "#111111"]);

  // Word-by-word illumination
  const { scrollYProgress } = useScroll({ target: textRef, offset: ["start 0.85", "end 0.5"] });
  const words = TEXT.split(" ");

  return (
    <motion.section
      id="manifesto"
      ref={sectionRef}
      style={{ backgroundColor: bg, color: fg }}
      className="relative scroll-mt-0"
      aria-labelledby="manifesto-label"
    >
      <div className="gutter section-y grid gap-12 md:grid-cols-12">
        <div className="md:col-span-3">
          <div id="manifesto-label" className="md:sticky md:top-32">
            <SectionLabel index="01">Manifesto</SectionLabel>
          </div>
        </div>
        <div className="md:col-span-9">
          <p ref={textRef} className="text-headline !leading-[1.04] text-balance" aria-label={TEXT.replace(/\*/g, "")}>
            <span aria-hidden="true">
              {words.map((w, i) => (
                <Word key={i} word={w} progress={scrollYProgress} range={[i / words.length, (i + 1) / words.length]} />
              ))}
            </span>
          </p>
          <Reveal className="mt-14 grid gap-8 border-t border-current/15 pt-8 md:mt-20 md:grid-cols-2">
            <p className="text-lede max-w-md opacity-75">
              Strategy, creative and performance marketing under one roof, so the big idea and the numbers never have to
              argue in separate meetings.
            </p>
            <div className="md:justify-self-end">
              <ArrowLink href="/about">How we think</ArrowLink>
            </div>
          </Reveal>
        </div>
      </div>
      <div className="border-y border-current/15 py-6 md:py-8">
        <Marquee
          className="font-display text-[clamp(2.5rem,7vw,6.5rem)] leading-none font-bold tracking-[-0.04em]"
          items={["Strategy", "Brand", "Advertising", "Web", "AI & Automation", "Content", "Growth"]}
          separator="✺"
        />
      </div>
    </motion.section>
  );
}
