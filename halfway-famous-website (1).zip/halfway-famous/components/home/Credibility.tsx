import { Reveal, SplitText } from "../Reveal";
import { PlaceholderTag, SectionLabel } from "../ui";

/**
 * Credibility frame. Intentionally empty: add genuine client logos, approved testimonials and verified metrics only.
 * Logos: drop SVGs into /public/clients and replace the <LogoSlot/> items.
 */
const metricSlots = ["[Projects launched]", "[Client ad spend managed]", "[Average client tenure]"];

function LogoSlot({ n }: { n: number }) {
  return (
    <li className="flex aspect-[3/2] items-center justify-center border-r border-b border-ink/12 p-6">
      <span className="flex flex-col items-center gap-2 text-center text-ink/35">
        <span className="font-display text-xs tracking-[0.18em] uppercase">Client logo</span>
        <span className="font-display text-[0.65rem]">0{n}</span>
      </span>
    </li>
  );
}

export function Credibility({ index = "06" }: { index?: string }) {
  return (
    <section className="bg-paper text-ink" aria-labelledby="proof-title">
      <div className="gutter section-y">
        <div className="grid gap-10 md:grid-cols-12 md:items-end">
          <div className="md:col-span-7">
            <SectionLabel index={index} className="mb-8">
              Proof
            </SectionLabel>
            <div id="proof-title">
              <SplitText as="h2" lines={["Proof, not", "*promises.*"]} className="text-display" />
            </div>
          </div>
          <Reveal className="md:col-span-5" delay={0.15}>
            <p className="text-lede opacity-75">
              This space is reserved for real clients, real results and real words. We&apos;d rather show you an empty
              frame than a fake one.
            </p>
          </Reveal>
        </div>

        {/* Logo wall */}
        <Reveal className="mt-16 md:mt-24">
          <ul className="grid grid-cols-2 border-t border-l border-ink/12 sm:grid-cols-4" aria-label="Client logos (to be added)">
            {Array.from({ length: 8 }).map((_, i) => (
              <LogoSlot key={i} n={i + 1} />
            ))}
          </ul>
        </Reveal>

        <div className="mt-20 grid gap-16 md:mt-28 md:grid-cols-12">
          {/* Testimonial frame */}
          <Reveal className="md:col-span-7">
            <figure className="relative">
              <span aria-hidden="true" className="absolute -top-10 -left-2 font-display text-[9rem] leading-none text-vermilion md:-top-14 md:text-[12rem]">
                “
              </span>
              <blockquote className="relative pt-14 font-display text-[clamp(1.6rem,3.2vw,3rem)] leading-[1.1] font-medium tracking-[-0.025em] text-ink/40">
                [A testimonial from a real client goes here, word for word, exactly as they approved it.]
              </blockquote>
              <figcaption className="mt-8 flex flex-wrap items-center gap-4 text-sm">
                <span className="h-px w-10 bg-ink/40" aria-hidden="true" />
                <span className="text-ink/60">[Name], [Title] — [Company]</span>
                <PlaceholderTag>Awaiting approval</PlaceholderTag>
              </figcaption>
            </figure>
          </Reveal>

          {/* Metric slots */}
          <Reveal className="md:col-span-4 md:col-start-9" delay={0.1}>
            <dl className="divide-y divide-ink/12 border-y border-ink/12">
              {metricSlots.map((label) => (
                <div key={label} className="flex items-baseline justify-between gap-6 py-6">
                  <dt className="text-sm text-ink/60">{label}</dt>
                  <dd className="font-display text-5xl font-bold tracking-tight text-ink/25">00</dd>
                </div>
              ))}
            </dl>
            <p className="mt-4 text-xs text-ink/50">Verified figures only. Add when ready.</p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
