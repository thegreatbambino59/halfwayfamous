import { projects } from "@/lib/content";
import { WorkPanel } from "../WorkPanel";
import { SplitText, Reveal } from "../Reveal";
import { ButtonLink, SectionLabel } from "../ui";

export function FeaturedWork() {
  const [a, b, c] = projects;
  return (
    <section className="bg-paper text-ink" aria-labelledby="work-title">
      <div className="gutter section-y">
        <div className="grid gap-8 md:grid-cols-12 md:items-end">
          <div className="md:col-span-8">
            <SectionLabel index="02" className="mb-8">
              Selected work
            </SectionLabel>
            <div id="work-title">
              <SplitText as="h2" lines={["Work that refuses", "to sit *still.*"]} className="text-display" />
            </div>
          </div>
          <Reveal className="md:col-span-4" delay={0.2}>
            <p className="text-lede opacity-75">
              Three example projects showing how we think and build. Real client case studies will live here as they&apos;re
              approved for publication.
            </p>
          </Reveal>
        </div>

        <div className="mt-16 grid gap-x-8 gap-y-16 md:mt-24 md:grid-cols-12 md:gap-y-24">
          <Reveal className="md:col-span-8">
            <WorkPanel project={a} index={0} aspect="aspect-[4/3] md:aspect-[16/11]" />
          </Reveal>
          <Reveal className="md:col-span-4 md:mt-[38%]" delay={0.1}>
            <WorkPanel project={b} index={1} aspect="aspect-[4/5]" />
          </Reveal>
          <Reveal className="md:col-span-7 md:col-start-3 md:-mt-8">
            <WorkPanel project={c} index={2} aspect="aspect-[4/3] md:aspect-[16/9]" />
          </Reveal>
        </div>

        <div className="mt-20 flex justify-center md:mt-28">
          <ButtonLink href="/work" tone="ghost-dark">
            See all work
          </ButtonLink>
        </div>
      </div>
    </section>
  );
}
