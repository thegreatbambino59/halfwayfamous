"use client";

import { motion } from "motion/react";
import { EASE, Reveal, SplitText } from "../Reveal";
import { SectionLabel } from "../ui";
import { LogoMark } from "../Logo";
import { cn } from "@/lib/cn";

const crossed = [
  { word: "Safe.", align: "justify-start" },
  { word: "Fine.", align: "justify-end" },
  { word: "On-brand.", align: "justify-center" },
  { word: "Expected.", align: "justify-start md:pl-[12%]" },
  { word: "Forgettable.", align: "justify-end" },
];

export function Philosophy() {
  return (
    <section className="relative overflow-hidden bg-paper text-ink" aria-labelledby="philosophy-title">
      <div className="gutter section-y">
        <SectionLabel index="04" className="mb-12 md:mb-20">
          Philosophy
        </SectionLabel>

        <h2 id="philosophy-title" className="sr-only">
          Why extraordinary creative work matters
        </h2>

        <ul aria-label="Things we refuse to make" className="space-y-1 md:space-y-0">
          {crossed.map((c, i) => (
            <li key={c.word} className={cn("flex", c.align)}>
              <span className="relative inline-block font-display text-[clamp(3rem,11vw,11rem)] leading-[0.95] font-bold tracking-[-0.04em] text-ash/70">
                {c.word}
                <motion.span
                  aria-hidden="true"
                  className="absolute top-[54%] left-[-3%] h-[0.09em] w-[106%] origin-left bg-vermilion"
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  viewport={{ once: true, amount: 0.9 }}
                  transition={{ duration: 0.9, ease: EASE, delay: 0.15 + i * 0.05 }}
                />
              </span>
            </li>
          ))}
        </ul>

        <div className="mt-20 grid gap-12 md:mt-32 md:grid-cols-12">
          <div className="md:col-span-8">
            <SplitText
              as="p"
              lines={["Nobody ever shared", "something because", "it was *fine.*"]}
              className="text-display"
            />
          </div>
        </div>

        <div className="mt-24 grid gap-12 border-t border-ink/15 pt-12 md:mt-36 md:grid-cols-12 md:pt-16">
          <Reveal className="md:col-span-4">
            <div className="flex items-center gap-5">
              <LogoMark className="h-16 w-16 text-ink" />
              <p className="text-eyebrow">On the name</p>
            </div>
          </Reveal>
          <Reveal className="md:col-span-7 md:col-start-6" delay={0.1}>
            <p className="font-display text-[clamp(1.6rem,3vw,2.75rem)] leading-[1.12] font-medium tracking-[-0.025em]">
              Famous is a finish line, and finish lines make people stop. <span className="text-vermilion">Halfway</span>{" "}
              is momentum: far enough along to prove it works, hungry enough to keep going.
            </p>
            <p className="text-lede mt-8 max-w-2xl opacity-70">
              Extraordinary work isn&apos;t decoration. It is the cheapest media you&apos;ll ever buy. Distinctive brands
              get noticed faster, remembered longer and shared for free. Ordinary work has to pay for every second of
              attention it gets.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
