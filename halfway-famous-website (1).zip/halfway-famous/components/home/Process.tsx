"use client";

import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { processSteps } from "@/lib/content";
import { SectionLabel } from "../ui";
import { SplitText } from "../Reveal";

function Glyph({ i }: { i: number }) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.5 } as const;
  return (
    <svg viewBox="0 0 80 80" className="h-16 w-16 md:h-24 md:w-24" aria-hidden="true">
      {i === 0 && (
        <>
          <circle cx="40" cy="40" r="26" {...common} />
          <circle cx="40" cy="40" r="8" fill="#E44632" />
          <path d="M40 4v14M40 62v14M4 40h14M62 40h14" {...common} />
        </>
      )}
      {i === 1 && (
        <>
          <path d="M12 38a28 28 0 0 1 56 0Z" fill="#E44632" />
          <path d="M12 44h56a28 28 0 0 1-56 0Z" {...common} />
        </>
      )}
      {i === 2 && (
        <>
          <path d="M40 8 66 64H14Z" {...common} />
          <path d="M40 30v42" stroke="#E44632" strokeWidth="3" />
        </>
      )}
      {i === 3 && (
        <>
          <path d="M62 40a22 22 0 1 1-6.4-15.6" {...common} />
          <path d="M58 14v12H46" {...common} />
          <circle cx="40" cy="40" r="5" fill="#E44632" />
        </>
      )}
    </svg>
  );
}

function Step({ step, copy, detail, i }: (typeof processSteps)[number] & { i: number }) {
  const ref = useRef<HTMLLIElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 0.9", "start 0.35"] });
  const clip = useTransform(scrollYProgress, [0, 1], ["inset(0 100% 0 0)", "inset(0 0% 0 0)"]);

  return (
    <li ref={ref} className="grid gap-6 border-t border-paper/15 py-10 md:grid-cols-12 md:items-center md:gap-8 md:py-14">
      <span className="font-display text-sm text-ash md:col-span-1">0{i + 1}</span>
      <div className="relative md:col-span-6">
        <span
          aria-hidden="true"
          className="block font-display text-[clamp(3.25rem,10vw,10rem)] leading-[0.86] font-bold tracking-[-0.04em] text-transparent [-webkit-text-stroke:1.5px_rgba(242,240,234,0.45)]"
        >
          {step}
        </span>
        <motion.span
          style={{ clipPath: clip }}
          className="absolute inset-0 block font-display text-[clamp(3.25rem,10vw,10rem)] leading-[0.86] font-bold tracking-[-0.04em] text-paper"
        >
          {step}
        </motion.span>
      </div>
      <div className="flex items-start gap-6 md:col-span-5 md:gap-10">
        <span className="shrink-0 text-paper/80">
          <Glyph i={i} />
        </span>
        <div>
          <p className="text-[1.05rem] leading-relaxed text-paper/80">{copy}</p>
          <p className="text-eyebrow mt-4 text-vermilion">{detail}</p>
        </div>
      </div>
    </li>
  );
}

export function Process({ index = "05" }: { index?: string }) {
  return (
    <section className="bg-ink text-paper" aria-labelledby="process-title">
      <div className="gutter section-y">
        <div className="mb-16 md:mb-20">
          <SectionLabel index={index} className="mb-8 text-ash">
            Process
          </SectionLabel>
          <div id="process-title">
            <SplitText as="h2" lines={["Four moves.", "No *magic tricks.*"]} className="text-display" />
          </div>
        </div>
        <ol className="border-b border-paper/15">
          {processSteps.map((p, i) => (
            <Step key={p.step} {...p} i={i} />
          ))}
        </ol>
      </div>
    </section>
  );
}
