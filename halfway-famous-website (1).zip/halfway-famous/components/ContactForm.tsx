"use client";

import { AnimatePresence, motion } from "motion/react";
import { useState, type FormEvent } from "react";
import { services } from "@/lib/content";
import { EASE } from "./Reveal";
import { Arrow } from "./ui";
import { cn } from "@/lib/cn";

const budgets = ["Under $10k", "$10k–$25k", "$25k–$50k", "$50k–$100k", "$100k+", "Not sure yet"];

type Status = "idle" | "sending" | "sent" | "error";

const field =
  "peer w-full border-0 border-b border-ink/25 bg-transparent px-0 pt-7 pb-3 text-[1.15rem] text-ink placeholder-transparent transition-colors focus:border-vermilion focus:ring-0 focus:outline-none";
const label =
  "pointer-events-none absolute top-7 left-0 text-[1.15rem] text-ink/50 transition-all duration-300 peer-focus:top-0 peer-focus:text-xs peer-focus:tracking-[0.12em] peer-focus:uppercase peer-[:not(:placeholder-shown)]:top-0 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:tracking-[0.12em] peer-[:not(:placeholder-shown)]:uppercase";

export function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);
  const [picked, setPicked] = useState<string[]>([]);
  const [budget, setBudget] = useState<string>("");

  const toggle = (name: string) =>
    setPicked((p) => (p.includes(name) ? p.filter((x) => x !== name) : [...p, name]));

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    setStatus("sending");
    setError(null);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, services: picked, budget }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      if (!res.ok || !json.ok) throw new Error(json.error ?? "Something went wrong.");
      setStatus("sent");
      form.reset();
      setPicked([]);
      setBudget("");
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Something went wrong.");
    }
  }

  return (
    <AnimatePresence mode="wait">
      {status === "sent" ? (
        <motion.div
          key="sent"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: EASE }}
          className="py-10"
          role="status"
        >
          <p className="text-display">
            Message <span className="text-vermilion">received.</span>
          </p>
          <p className="text-lede mt-6 max-w-lg opacity-75">
            Thanks for reaching out. A real human will read this and reply within two business days.
          </p>
          <button
            type="button"
            onClick={() => setStatus("idle")}
            className="mt-10 font-display font-medium underline underline-offset-[6px]"
          >
            Send another message
          </button>
        </motion.div>
      ) : (
        <motion.form
          key="form"
          onSubmit={onSubmit}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, y: -20 }}
          className="space-y-10"
          noValidate={false}
        >
          <div className="grid gap-10 md:grid-cols-2">
            <div className="relative">
              <input id="name" name="name" required autoComplete="name" placeholder="Your name" className={field} />
              <label htmlFor="name" className={label}>
                Your name *
              </label>
            </div>
            <div className="relative">
              <input
                id="email"
                name="email"
                type="email"
                required
                autoComplete="email"
                placeholder="Email"
                className={field}
              />
              <label htmlFor="email" className={label}>
                Email *
              </label>
            </div>
            <div className="relative">
              <input id="company" name="company" autoComplete="organization" placeholder="Company" className={field} />
              <label htmlFor="company" className={label}>
                Company
              </label>
            </div>
            <div className="relative">
              <input id="website" name="website" type="url" placeholder="Website" className={field} />
              <label htmlFor="website" className={label}>
                Website
              </label>
            </div>
          </div>

          <fieldset>
            <legend className="text-eyebrow mb-5 opacity-60">What do you need?</legend>
            <div className="flex flex-wrap gap-2">
              {services.map((s) => {
                const on = picked.includes(s.name);
                return (
                  <button
                    key={s.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggle(s.name)}
                    className={cn(
                      "rounded-full border px-4 py-2.5 font-display text-[0.95rem] font-medium transition-colors duration-300",
                      on ? "border-vermilion bg-vermilion text-white" : "border-ink/20 hover:border-ink",
                    )}
                  >
                    {s.name}
                  </button>
                );
              })}
            </div>
          </fieldset>

          <fieldset>
            <legend className="text-eyebrow mb-5 opacity-60">Budget range</legend>
            <div className="flex flex-wrap gap-2" role="radiogroup">
              {budgets.map((b) => (
                <button
                  key={b}
                  type="button"
                  role="radio"
                  aria-checked={budget === b}
                  onClick={() => setBudget(b)}
                  className={cn(
                    "rounded-full border px-4 py-2.5 font-display text-[0.95rem] font-medium transition-colors duration-300",
                    budget === b ? "border-ink bg-ink text-paper" : "border-ink/20 hover:border-ink",
                  )}
                >
                  {b}
                </button>
              ))}
            </div>
          </fieldset>

          <div className="relative">
            <textarea
              id="message"
              name="message"
              required
              rows={4}
              placeholder="Tell us about the project"
              className={cn(field, "resize-none")}
            />
            <label htmlFor="message" className={label}>
              Tell us about the project *
            </label>
          </div>

          {/* Honeypot */}
          <div aria-hidden="true" className="hidden">
            <label htmlFor="hp">Leave this empty</label>
            <input id="hp" name="hp" tabIndex={-1} autoComplete="off" />
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <button
              type="submit"
              disabled={status === "sending"}
              className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-ink px-8 py-5 font-display text-lg font-medium text-paper transition-colors disabled:opacity-60"
            >
              <span
                aria-hidden="true"
                className="absolute inset-0 translate-y-full rounded-full bg-vermilion transition-transform duration-500 ease-[var(--ease-expo)] group-hover:translate-y-0"
              />
              <span className="relative">{status === "sending" ? "Sending…" : "Send it"}</span>
              <Arrow className="relative transition-transform duration-500 group-hover:rotate-45" />
            </button>
            {status === "error" && (
              <p role="alert" className="text-sm text-vermilion-deep">
                {error}
              </p>
            )}
          </div>
        </motion.form>
      )}
    </AnimatePresence>
  );
}
