import Link from "next/link";
import { HalfWord, LogoMark } from "./Logo";
import { nav, services, site } from "@/lib/content";
import { Arrow } from "./ui";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="relative overflow-hidden bg-ink text-paper" aria-labelledby="footer-heading">
      <h2 id="footer-heading" className="sr-only">
        Footer
      </h2>
      <div className="gutter grid grid-cols-2 gap-x-6 gap-y-12 pt-20 pb-14 md:grid-cols-12 md:pt-28">
        <div className="col-span-2 md:col-span-5">
          <p className="max-w-sm font-display text-2xl leading-tight font-medium tracking-tight md:text-3xl">
            Further than most. <span className="text-ash">Not as far as we're going.</span>
          </p>
          <a
            href={`mailto:${site.email}`}
            className="group mt-8 inline-flex items-center gap-3 font-display text-xl font-medium md:text-2xl"
          >
            <span className="bg-[linear-gradient(var(--color-vermilion),var(--color-vermilion))] bg-[length:0%_2px] bg-left-bottom bg-no-repeat pb-1 transition-[background-size] duration-500 group-hover:bg-[length:100%_2px]">
              {site.email}
            </span>
            <Arrow className="text-vermilion transition-transform duration-500 group-hover:rotate-45" />
          </a>
        </div>

        <FooterCol title="Navigate" className="md:col-span-2 md:col-start-7">
          {[{ label: "Home", href: "/" }, ...nav].map((n) => (
            <FooterLink key={n.href} href={n.href}>
              {n.label}
            </FooterLink>
          ))}
        </FooterCol>

        <FooterCol title="Services" className="md:col-span-2">
          {services.map((s) => (
            <FooterLink key={s.id} href={`/services#${s.id}`}>
              {s.name}
            </FooterLink>
          ))}
        </FooterCol>

        <FooterCol title="Follow" className="md:col-span-2">
          {site.social.map((s) => (
            <li key={s.label}>
              <a href={s.href} className="text-paper/70 transition-colors hover:text-vermilion" rel="noopener noreferrer">
                {s.label}
              </a>
            </li>
          ))}
          <li className="pt-4 text-ash">{site.location}</li>
        </FooterCol>
      </div>

      <div className="gutter flex flex-col gap-5 border-t border-paper/10 py-8 text-xs text-ash md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-5">
          {/* Small brand lockup: the supplied logo (mark over HALꟻ), kept as a quiet sign-off */}
          <Link href="/" aria-label="Halfway Famous — home" className="flex flex-col items-center gap-1.5 text-paper/80 transition-colors hover:text-paper">
            <LogoMark className="h-8 w-8" />
            <HalfWord className="pl-[0.42em] text-[0.62rem]" />
          </Link>
          <p>© {year} Halfway Famous. All rights reserved.</p>
        </div>
        <p className="flex gap-6">
          <Link href="/privacy" className="hover:text-paper">
            Privacy
          </Link>
          <a href="#main" className="hover:text-paper">
            Back to top ↑
          </a>
        </p>
      </div>
    </footer>
  );
}

function FooterCol({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={className}>
      <p className="text-eyebrow mb-5 text-ash">{title}</p>
      <ul className="space-y-2.5 text-[0.95rem]">{children}</ul>
    </div>
  );
}

function FooterLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <li>
      <Link href={href} className="text-paper/70 transition-colors hover:text-vermilion">
        {children}
      </Link>
    </li>
  );
}
