"use client";

import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import type { ArtVariant } from "@/lib/content";
import { ArtPlate } from "./ArtPlate";

/** Full-bleed image that settles from a slight zoom as it scrolls into place. */
export function ParallaxPlate({ variant, label }: { variant: ArtVariant; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const scale = useTransform(scrollYProgress, [0, 0.5], [1.25, 1]);
  const y = useTransform(scrollYProgress, [0, 1], ["-6%", "6%"]);
  return (
    <div ref={ref} className="relative aspect-[4/3] overflow-hidden bg-ink md:aspect-[21/9]">
      <motion.div style={{ scale, y }} className="absolute inset-0">
        <ArtPlate variant={variant} label={label} />
      </motion.div>
      <span className="text-eyebrow absolute right-4 bottom-4 rounded-full bg-ink/70 px-3 py-2 text-paper backdrop-blur md:right-8 md:bottom-8">
        Placeholder visual
      </span>
    </div>
  );
}
