"use client";

import { motion, type HTMLMotionProps } from "motion/react";
import { createElement, type ReactNode } from "react";
import { cn } from "@/lib/cn";

export const EASE = [0.16, 1, 0.3, 1] as const;

type RevealProps = HTMLMotionProps<"div"> & {
  delay?: number;
  y?: number;
  children: ReactNode;
};

/** Fade + rise when the element enters the viewport. */
export function Reveal({ delay = 0, y = 36, children, className, ...rest }: RevealProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{ duration: 1.1, ease: EASE, delay }}
      className={className}
      {...rest}
    >
      {children}
    </motion.div>
  );
}

type SplitProps = {
  /** Each entry renders on its own line. Wrap a word in *asterisks* to accent it. */
  lines: string[];
  as?: "h1" | "h2" | "h3" | "p" | "div";
  className?: string;
  lineClassName?: string;
  delay?: number;
  stagger?: number;
  onMount?: boolean;
  accentClassName?: string;
};

/** Masked word-by-word headline reveal. Screen readers get the plain sentence. */
export function SplitText({
  lines,
  as = "h2",
  className,
  lineClassName,
  delay = 0,
  stagger = 0.06,
  onMount = false,
  accentClassName = "text-vermilion",
}: SplitProps) {
  const label = lines.join(" ").replace(/\*/g, "");
  let i = 0;
  const trigger = onMount
    ? { animate: "show" as const }
    : { whileInView: "show" as const, viewport: { once: true, amount: 0.3 } };

  const content = (
    <motion.span initial="hidden" {...trigger} aria-hidden="true" className="block">
      {lines.map((line, li) => (
        <span key={li} className={cn("block", lineClassName)}>
          {line.split(" ").map((word, wi) => {
            const accent = word.startsWith("*") && word.endsWith("*");
            const clean = word.replace(/\*/g, "");
            const idx = i++;
            return (
              <span key={wi} className="inline-block overflow-hidden pb-[0.08em] -mb-[0.08em] align-bottom">
                <motion.span
                  className={cn("inline-block will-change-transform", accent && accentClassName)}
                  variants={{
                    hidden: { y: "110%", rotate: 4 },
                    show: {
                      y: "0%",
                      rotate: 0,
                      transition: { duration: 1.05, ease: EASE, delay: delay + idx * stagger },
                    },
                  }}
                >
                  {clean}
                </motion.span>
                {wi < line.split(" ").length - 1 && <span>&nbsp;</span>}
              </span>
            );
          })}
        </span>
      ))}
    </motion.span>
  );

  return createElement(as, { className, "aria-label": label }, content);
}
