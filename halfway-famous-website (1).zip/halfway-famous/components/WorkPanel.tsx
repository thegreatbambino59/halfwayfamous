"use client";

import Link from "next/link";
import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import type { Project } from "@/lib/content";
import { ArtPlate } from "./ArtPlate";
import { Arrow, PlaceholderTag } from "./ui";
import { cn } from "@/lib/cn";

/** Immersive case-study panel: scroll-linked image scale, hover reveal on desktop, always-visible details on touch. */
export function WorkPanel({
  project,
  index,
  aspect = "aspect-[16/10]",
  className,
  priority,
}: {
  project: Project;
  index: number;
  aspect?: string;
  className?: string;
  priority?: boolean;
}) {
  const ref = useRef<HTMLAnchorElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const scale = useTransform(scrollYProgress, [0, 0.5], [1.18, 1]);
  const num = String(index + 1).padStart(2, "0");

  return (
    <Link
      ref={ref}
      href={`/work/${project.slug}`}
      className={cn("group block", className)}
      aria-label={`${project.title}, example case study`}
      data-priority={priority || undefined}
    >
      <div className={cn("relative overflow-hidden rounded-[3px] bg-ink", aspect)}>
        <motion.div style={{ scale }} className="absolute inset-0">
          <div className="h-full w-full transition-transform duration-[1.4s] ease-[var(--ease-expo)] group-hover:scale-[1.06]">
            <ArtPlate variant={project.art} />
          </div>
        </motion.div>

        <div className="absolute top-4 left-4 z-10 md:top-5 md:left-5">
          <PlaceholderTag className="border-transparent bg-ink/75 text-paper backdrop-blur-sm" />
        </div>
        <span className="absolute top-4 right-4 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-ink/75 font-display text-xs font-medium text-paper backdrop-blur-sm md:top-5 md:right-5">
          {num}
        </span>

        {/* Hover reveal (pointer devices) */}
        <div className="absolute inset-x-0 bottom-0 z-10 hidden translate-y-full bg-ink/92 p-6 text-paper backdrop-blur-sm transition-transform duration-700 ease-[var(--ease-expo)] group-hover:translate-y-0 group-focus-visible:translate-y-0 md:block lg:p-8">
          <p className="max-w-xl text-[1.02rem] leading-relaxed text-paper/85">{project.summary}</p>
          <div className="mt-5 flex flex-wrap gap-x-10 gap-y-3 border-t border-paper/15 pt-5">
            {project.metrics.map((m) => (
              <div key={m.label}>
                <p className="font-display text-3xl font-bold tracking-tight text-vermilion">{m.value}</p>
                <p className="text-xs text-ash">{m.label}</p>
              </div>
            ))}
            <p className="ml-auto self-end text-[0.65rem] tracking-[0.14em] text-ash uppercase">Placeholder metrics</p>
          </div>
        </div>
      </div>

      <div className="mt-5 flex items-start justify-between gap-6">
        <div>
          <p className="text-eyebrow opacity-60">
            {project.sector} · {project.disciplines.join(" / ")}
          </p>
          <h3 className="text-title mt-3 transition-colors duration-300 group-hover:text-vermilion">{project.title}</h3>
          <p className="mt-3 max-w-lg text-[0.98rem] leading-relaxed opacity-75 md:hidden">{project.summary}</p>
        </div>
        <span className="mt-6 flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-current/25 transition-all duration-500 group-hover:rotate-45 group-hover:border-vermilion group-hover:bg-vermilion group-hover:text-white">
          <Arrow />
        </span>
      </div>
    </Link>
  );
}
