import type { ArtVariant } from "@/lib/content";
import { cn } from "@/lib/cn";

/**
 * Original generative art plates used as clearly-labeled placeholder imagery.
 * Swap for real project photography / film stills by replacing <ArtPlate/> with next/image.
 */

const INK = "#111111";
const PAPER = "#F2F0EA";
const VERM = "#E44632";
const ASH = "#A7A79F";

function topoPaths(cx: number, cy: number, rings: number, seed: number) {
  const paths: string[] = [];
  for (let r = 1; r <= rings; r++) {
    const base = r * 34;
    const pts: string[] = [];
    for (let a = 0; a <= 64; a++) {
      const t = (a / 64) * Math.PI * 2;
      const wobble =
        Math.sin(t * 3 + seed + r * 0.35) * (8 + r * 1.6) + Math.cos(t * 5 - seed * 0.7 + r * 0.2) * (4 + r * 0.8);
      const rad = base + wobble;
      const x = cx + Math.cos(t) * rad * 1.15;
      const y = cy + Math.sin(t) * rad;
      pts.push(`${a === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    paths.push(pts.join("") + "Z");
  }
  return paths;
}

function Sun() {
  return (
    <>
      <rect width="1000" height="1000" fill={INK} />
      {[180, 250, 320, 390, 460].map((r, i) => (
        <circle key={r} cx="500" cy="600" r={r} fill="none" stroke={PAPER} strokeOpacity={0.18 - i * 0.025} strokeWidth="1.5" />
      ))}
      <path d="M260 600a240 240 0 0 1 480 0Z" fill={VERM} />
      <line x1="0" y1="600" x2="1000" y2="600" stroke={PAPER} strokeOpacity="0.6" strokeWidth="2" />
      {Array.from({ length: 9 }).map((_, i) => {
        const y = 630 + i * (18 + i * 4);
        const w = 420 - i * 38;
        return <rect key={i} x={500 - w / 2} y={y} width={w} height={10 - i * 0.8} fill={VERM} opacity={0.85 - i * 0.08} />;
      })}
    </>
  );
}

function Topo() {
  const paths = topoPaths(560, 470, 16, 1.7);
  return (
    <>
      <rect width="1000" height="1000" fill="#1a1a19" />
      {paths.map((d, i) => (
        <path key={i} d={d} fill="none" stroke={PAPER} strokeOpacity={i % 4 === 0 ? 0.55 : 0.2} strokeWidth={i % 4 === 0 ? 1.8 : 1.1} />
      ))}
      <line x1="0" y1="470" x2="1000" y2="470" stroke={ASH} strokeOpacity="0.25" strokeDasharray="4 8" />
      <line x1="560" y1="0" x2="560" y2="1000" stroke={ASH} strokeOpacity="0.25" strokeDasharray="4 8" />
      <circle cx="560" cy="470" r="34" fill="none" stroke={VERM} strokeWidth="2" />
      <circle cx="560" cy="470" r="11" fill={VERM} />
      <text x="600" y="430" fill={PAPER} fontFamily="monospace" fontSize="18" letterSpacing="2" opacity="0.7">
        40.39°N 111.85°W
      </text>
    </>
  );
}

function Halves() {
  const cells = [];
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 4; c++) {
      const x = 110 + c * 200;
      const y = 80 + r * 180;
      const up = (r + c) % 2 === 0;
      const accent = r === 2 && c === 2;
      cells.push(
        <path
          key={`${r}-${c}`}
          d={
            up
              ? `M${x} ${y + 20}h180v20a60 60 0 0 1-60 60h-60a60 60 0 0 1-60-60Z`
              : `M${x + 60} ${y + 20}h60a60 60 0 0 1 60 60v20h-180v-20a60 60 0 0 1 60-60Z`
          }
          fill={accent ? VERM : INK}
        />,
      );
    }
  }
  return (
    <>
      <rect width="1000" height="1000" fill={PAPER} />
      {cells}
    </>
  );
}

function Signal() {
  const bars = Array.from({ length: 23 }).map((_, i) => {
    const h = 80 + Math.abs(Math.sin(i * 0.9) * 320 + Math.cos(i * 0.37) * 160);
    return { x: 95 + i * 36, h };
  });
  return (
    <>
      <rect width="1000" height="1000" fill={VERM} />
      {bars.map((b, i) => (
        <rect key={i} x={b.x} y={500 - b.h / 2} width="18" height={b.h} rx="9" fill={i === 11 ? PAPER : INK} />
      ))}
    </>
  );
}

function Grid() {
  return (
    <>
      <rect width="1000" height="1000" fill="#E7E4DB" />
      {Array.from({ length: 11 }).map((_, i) => (
        <g key={i}>
          <line x1={i * 100} y1="0" x2={i * 100} y2="1000" stroke={INK} strokeOpacity="0.08" />
          <line x1="0" y1={i * 100} x2="1000" y2={i * 100} stroke={INK} strokeOpacity="0.08" />
        </g>
      ))}
      <rect x="200" y="200" width="400" height="500" rx="24" fill={INK} />
      <circle cx="650" cy="650" r="170" fill={VERM} />
      <rect x="300" y="300" width="200" height="40" fill={PAPER} />
      <rect x="300" y="370" width="140" height="40" fill={PAPER} opacity="0.6" />
      <path d="M600 200h200v100H700a100 100 0 0 1-100-100Z" fill={INK} />
    </>
  );
}

function Orbit() {
  return (
    <>
      <rect width="1000" height="1000" fill={INK} />
      {[0, 30, 60, 90, 120, 150].map((deg, i) => (
        <ellipse
          key={deg}
          cx="500"
          cy="500"
          rx="400"
          ry="150"
          fill="none"
          stroke={i === 2 ? VERM : ASH}
          strokeOpacity={i === 2 ? 0.9 : 0.3}
          strokeWidth={i === 2 ? 2 : 1.2}
          transform={`rotate(${deg} 500 500)`}
        />
      ))}
      <path d="M380 500a120 120 0 0 1 240 0Z" fill={PAPER} />
      <path d="M380 520h240a120 120 0 0 1-240 0Z" fill={PAPER} opacity="0.25" />
      <circle cx="827" cy="311" r="18" fill={VERM} />
    </>
  );
}

const map: Record<ArtVariant, () => React.JSX.Element> = {
  sun: Sun,
  topo: Topo,
  halves: Halves,
  signal: Signal,
  grid: Grid,
  orbit: Orbit,
};

export function ArtPlate({
  variant,
  className,
  label,
  decorative,
}: {
  variant: ArtVariant;
  className?: string;
  label?: string;
  decorative?: boolean;
}) {
  const Art = map[variant];
  return (
    <svg
      viewBox="0 0 1000 1000"
      preserveAspectRatio="xMidYMid slice"
      className={cn("block h-full w-full", className)}
      role={decorative ? undefined : "img"}
      aria-hidden={decorative || undefined}
      aria-label={decorative ? undefined : (label ?? "Abstract placeholder artwork")}
    >
      <Art />
    </svg>
  );
}
