import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/PageHero";
import { Reveal } from "@/components/Reveal";
import { ArtPlate } from "@/components/ArtPlate";
import { Arrow, PlaceholderTag } from "@/components/ui";
import { ContactCTA } from "@/components/ContactCTA";
import { insights, type ArtVariant } from "@/lib/content";

export const metadata: Metadata = {
  title: "Insights",
  description: "Opinions on brand, advertising, web and AI from the Halfway Famous team.",
  alternates: { canonical: "/insights" },
};

const art: ArtVariant[] = ["sun", "orbit", "signal", "grid"];

export default function InsightsPage() {
  const [featured, ...rest] = insights;
  return (
    <>
      <PageHero
        eyebrow="Insights"
        title={["Loud", "*opinions.*"]}
        intro={<p>Notes on brand, advertising, websites and AI. Written to be useful, occasionally to be argued with.</p>}
        aside={<PlaceholderTag className="text-paper">Draft articles · review before publishing</PlaceholderTag>}
      />

      <section className="bg-paper text-ink" aria-label="Articles">
        <div className="gutter section-y">
          {/* Featured */}
          <Reveal>
            <Link href={`/insights/${featured.slug}`} className="group grid gap-8 md:grid-cols-12 md:items-end">
              <div className="relative aspect-[4/3] overflow-hidden rounded-[3px] md:col-span-7">
                <div className="h-full w-full transition-transform duration-[1.4s] ease-[var(--ease-expo)] group-hover:scale-105">
                  <ArtPlate variant={art[0]} decorative />
                </div>
                <span className="text-eyebrow absolute top-4 left-4 rounded-full bg-paper px-3 py-1.5 text-ink">
                  Featured
                </span>
              </div>
              <div className="md:col-span-5">
                <p className="text-eyebrow opacity-60">
                  {featured.category} · {featured.readTime}
                </p>
                <h2 className="text-headline mt-5 transition-colors group-hover:text-vermilion">{featured.title}</h2>
                <p className="text-lede mt-6 opacity-70">{featured.excerpt}</p>
                <span className="mt-8 inline-flex items-center gap-2 font-display font-medium">
                  Read the article <Arrow className="transition-transform duration-500 group-hover:rotate-45" />
                </span>
              </div>
            </Link>
          </Reveal>

          {/* Index */}
          <ul className="mt-24 border-t border-ink/15 md:mt-36">
            {rest.map((a, i) => (
              <li key={a.slug} className="border-b border-ink/15">
                <Link
                  href={`/insights/${a.slug}`}
                  className="group relative grid gap-4 overflow-hidden py-8 md:grid-cols-12 md:items-center md:py-10"
                >
                  <span className="text-eyebrow opacity-60 md:col-span-2">{a.category}</span>
                  <h2 className="font-display text-[clamp(1.6rem,3.2vw,3rem)] leading-[1.02] font-semibold tracking-[-0.035em] transition-transform duration-700 ease-[var(--ease-expo)] md:col-span-7 md:group-hover:translate-x-4">
                    {a.title}
                  </h2>
                  <span className="text-sm opacity-60 md:col-span-2">{a.readTime}</span>
                  <span className="hidden h-12 w-12 items-center justify-center justify-self-end rounded-full border border-ink/20 transition-all duration-500 group-hover:rotate-45 group-hover:border-vermilion group-hover:bg-vermilion group-hover:text-white md:col-span-1 md:flex">
                    <Arrow />
                  </span>
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute top-1/2 right-24 hidden h-28 w-40 -translate-y-1/2 scale-75 overflow-hidden rounded-[3px] opacity-0 transition-all duration-500 group-hover:scale-100 group-hover:opacity-100 lg:block"
                  >
                    <ArtPlate variant={art[(i + 1) % art.length]} decorative />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <ContactCTA
        lines={["RATHER TALK", "THAN *READ?*"]}
        copy="Bring us the problem you can't stop thinking about. We'll bring opinions, ideas and a plan."
      />
    </>
  );
}
