import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { insights } from "@/lib/content";
import { SplitText, Reveal } from "@/components/Reveal";
import { HorizonRule } from "@/components/HorizonRule";
import { ArrowLink, PlaceholderTag } from "@/components/ui";
import { ContactCTA } from "@/components/ContactCTA";

type Params = { slug: string };

export function generateStaticParams() {
  return insights.map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const a = insights.find((x) => x.slug === slug);
  if (!a) return {};
  return {
    title: a.title,
    description: a.excerpt,
    alternates: { canonical: `/insights/${a.slug}` },
    openGraph: { type: "article", title: a.title, description: a.excerpt },
  };
}

export default async function ArticlePage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const idx = insights.findIndex((a) => a.slug === slug);
  if (idx === -1) notFound();
  const a = insights[idx];
  const next = insights[(idx + 1) % insights.length];

  return (
    <article>
      <header className="grain relative overflow-hidden bg-ink pt-36 pb-16 text-paper md:pt-48 md:pb-20">
        <div className="gutter relative z-[3]">
          <div className="mb-10 flex flex-wrap items-center gap-4">
            <Link href="/insights" className="text-eyebrow text-ash hover:text-paper">
              ← Insights
            </Link>
            <PlaceholderTag className="text-paper">Draft</PlaceholderTag>
          </div>
          <SplitText as="h1" lines={[a.title]} className="text-display max-w-[18ch]" onMount stagger={0.04} />
          <p className="text-eyebrow mt-12 text-ash">
            {a.category} · {a.readTime} · {a.date}
          </p>
          <div className="mt-10">
            <HorizonRule />
          </div>
        </div>
      </header>

      <div className="bg-paper text-ink">
        <div className="gutter section-y grid gap-12 md:grid-cols-12">
          <aside className="md:col-span-3">
            <div className="md:sticky md:top-28">
              <p className="text-eyebrow opacity-60">Written by</p>
              <p className="mt-3 font-display text-lg font-medium">[Author name]</p>
            </div>
          </aside>
          <div className="md:col-span-7">
            <Reveal>
              <p className="font-display text-[clamp(1.5rem,2.4vw,2.2rem)] leading-[1.22] font-medium tracking-[-0.02em]">
                {a.excerpt}
              </p>
            </Reveal>
            <div className="mt-12 space-y-7 text-[1.15rem] leading-[1.75] text-ink/80">
              {a.body.map((para, i) => (
                <Reveal key={i}>
                  <p className={i === 0 ? "first-letter:float-left first-letter:mr-3 first-letter:font-display first-letter:text-[4.4rem] first-letter:leading-[0.8] first-letter:font-bold first-letter:text-vermilion" : undefined}>
                    {para}
                  </p>
                </Reveal>
              ))}
            </div>
            <div className="mt-16 flex flex-wrap items-center justify-between gap-6 border-t border-ink/15 pt-8">
              <p className="text-sm opacity-60">Next: {next.title}</p>
              <ArrowLink href={`/insights/${next.slug}`}>Keep reading</ArrowLink>
            </div>
          </div>
        </div>
      </div>

      <ContactCTA />
    </article>
  );
}
