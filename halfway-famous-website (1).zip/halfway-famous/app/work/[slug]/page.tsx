import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { projects, type ArtVariant } from "@/lib/content";
import { ArtPlate } from "@/components/ArtPlate";
import { ParallaxPlate } from "@/components/ParallaxPlate";
import { Reveal, SplitText } from "@/components/Reveal";
import { Arrow, PlaceholderTag, SectionLabel } from "@/components/ui";
import { ContactCTA } from "@/components/ContactCTA";

type Params = { slug: string };

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const p = projects.find((x) => x.slug === slug);
  if (!p) return {};
  return {
    title: `${p.title} — Example case study`,
    description: p.summary,
    alternates: { canonical: `/work/${p.slug}` },
  };
}

const alt: Record<ArtVariant, [ArtVariant, ArtVariant]> = {
  sun: ["signal", "orbit"],
  topo: ["grid", "sun"],
  halves: ["orbit", "signal"],
  signal: ["halves", "grid"],
  grid: ["topo", "halves"],
  orbit: ["sun", "topo"],
};

export default async function CaseStudyPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const idx = projects.findIndex((p) => p.slug === slug);
  if (idx === -1) notFound();
  const p = projects[idx];
  const next = projects[(idx + 1) % projects.length];
  const [g1, g2] = alt[p.art];

  return (
    <article>
      {/* Hero */}
      <header className="grain relative overflow-hidden bg-ink pt-36 pb-14 text-paper md:pt-48 md:pb-20">
        <div className="gutter relative z-[3]">
          <div className="mb-10 flex flex-wrap items-center gap-4">
            <Link href="/work" className="text-eyebrow text-ash transition-colors hover:text-paper">
              ← All work
            </Link>
            <PlaceholderTag className="text-paper">Example case study</PlaceholderTag>
          </div>
          <SplitText as="h1" lines={[p.title]} className="text-display max-w-[14ch]" onMount />
          <dl className="mt-14 grid grid-cols-2 gap-y-8 border-t border-paper/15 pt-8 md:mt-20 md:grid-cols-4">
            {[
              ["Client", p.client],
              ["Sector", p.sector],
              ["Services", p.disciplines.join(", ")],
              ["Year", p.year],
            ].map(([k, v]) => (
              <div key={k} className="pr-6">
                <dt className="text-eyebrow text-ash">{k}</dt>
                <dd className="mt-3 text-[1.02rem] text-paper/90">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </header>

      <ParallaxPlate variant={p.art} label={`${p.title} key visual (placeholder)`} />

      {/* Narrative */}
      <section className="bg-paper text-ink">
        <div className="gutter section-y">
          <div
            role="note"
            className="mb-20 flex flex-col gap-3 rounded-[3px] border border-ink/15 bg-paper-2 p-5 text-sm text-ink/70 md:flex-row md:items-center md:gap-6"
          >
            <PlaceholderTag>Placeholder</PlaceholderTag>
            <p>
              This is an illustrative case study written to demonstrate layout and storytelling. Replace it with a genuine,
              client-approved project before launch.
            </p>
          </div>

          <div className="grid gap-12 md:grid-cols-12">
            <div className="md:col-span-3">
              <SectionLabel index="01">The challenge</SectionLabel>
            </div>
            <Reveal className="md:col-span-8 md:col-start-5">
              <p className="text-title !font-medium">{p.challenge}</p>
            </Reveal>
          </div>

          <div className="mt-24 grid gap-12 md:mt-36 md:grid-cols-12">
            <div className="md:col-span-3">
              <SectionLabel index="02">The idea</SectionLabel>
            </div>
            <Reveal className="md:col-span-9 md:col-start-4">
              <p className="text-headline">
                <span className="text-vermilion">“</span>
                {p.idea}
                <span className="text-vermilion">”</span>
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="bg-paper pb-4 text-ink" aria-label="Project imagery (placeholders)">
        <div className="gutter grid gap-4 md:grid-cols-12">
          <Reveal className="relative aspect-[4/5] overflow-hidden rounded-[3px] md:col-span-5">
            <ArtPlate variant={g1} label="Placeholder project image" />
          </Reveal>
          <Reveal className="relative aspect-[4/5] overflow-hidden rounded-[3px] md:col-span-7 md:aspect-auto" delay={0.1}>
            <ArtPlate variant={g2} label="Placeholder project image" />
          </Reveal>
        </div>
      </section>

      {/* Execution + Results */}
      <section className="bg-paper text-ink">
        <div className="gutter section-y grid gap-16 md:grid-cols-12">
          <div className="md:col-span-5">
            <SectionLabel index="03" className="mb-10">
              What we did
            </SectionLabel>
            <ol className="border-t border-ink/15">
              {p.execution.map((e, i) => (
                <li key={e} className="border-b border-ink/15">
                  <Reveal delay={i * 0.05} className="flex gap-6 py-5">
                    <span className="font-display text-sm text-vermilion">0{i + 1}</span>
                    <span className="text-[1.05rem]">{e}</span>
                  </Reveal>
                </li>
              ))}
            </ol>
          </div>
          <div className="md:col-span-6 md:col-start-7">
            <SectionLabel index="04" className="mb-10">
              Results
            </SectionLabel>
            <div className="grid grid-cols-2 gap-8">
              {p.metrics.map((m) => (
                <Reveal key={m.label}>
                  <p className="font-display text-[clamp(3rem,7vw,6rem)] leading-none font-bold tracking-[-0.05em] text-ink/25">
                    {m.value}
                  </p>
                  <p className="mt-3 text-sm text-ink/60">{m.label}</p>
                </Reveal>
              ))}
            </div>
            <p className="mt-10 text-[1.02rem] leading-relaxed text-ink/60">{p.outcome}</p>
          </div>
        </div>
      </section>

      {/* Next project */}
      <Link
        href={`/work/${next.slug}`}
        className="group relative block overflow-hidden bg-ink text-paper"
        aria-label={`Next project: ${next.title}`}
      >
        <div className="absolute inset-0 opacity-30 transition-[opacity,transform] duration-[1.2s] ease-[var(--ease-expo)] group-hover:scale-105 group-hover:opacity-60">
          <ArtPlate variant={next.art} decorative />
        </div>
        <div className="gutter relative z-10 flex flex-col gap-6 py-24 md:flex-row md:items-end md:justify-between md:py-36">
          <div>
            <p className="text-eyebrow text-ash">Next project</p>
            <p className="text-display mt-6">{next.title}</p>
          </div>
          <span className="flex h-20 w-20 items-center justify-center rounded-full bg-vermilion text-3xl text-white transition-transform duration-700 group-hover:rotate-45">
            <Arrow />
          </span>
        </div>
      </Link>

      <ContactCTA />
    </article>
  );
}
