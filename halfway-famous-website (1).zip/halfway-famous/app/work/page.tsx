import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { WorkIndex } from "@/components/WorkIndex";
import { ContactCTA } from "@/components/ContactCTA";

export const metadata: Metadata = {
  title: "Work",
  description: "Selected brand, advertising, web and automation projects from Halfway Famous.",
  alternates: { canonical: "/work" },
};

export default function WorkPage() {
  return (
    <>
      <PageHero
        eyebrow="Selected work"
        title={["The *work.*"]}
        intro={
          <p>
            Brands, campaigns, websites and systems built to be noticed and built to perform. The projects below are
            illustrative examples of how we approach a brief. Genuine client case studies will replace them as they&apos;re
            approved for publication.
          </p>
        }
      />
      <WorkIndex />
      <ContactCTA lines={["YOUR PROJECT", "GOES *HERE.*"]} copy="The best case study on this page hasn't been made yet. Let's make it together." />
    </>
  );
}
