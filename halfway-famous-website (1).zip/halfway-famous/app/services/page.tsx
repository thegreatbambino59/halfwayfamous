import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { Reveal } from "@/components/Reveal";
import { SectionLabel } from "@/components/ui";
import { Process } from "@/components/home/Process";
import { ContactCTA } from "@/components/ContactCTA";
import { services } from "@/lib/content";

export const metadata: Metadata = {
  title: "Services",
  description:
    "Strategy & consulting, brand & creative, digital advertising, web design & development, and AI & automation from Halfway Famous.",
  alternates: { canonical: "/services" },
};

const models = [
  {
    name: "Projects",
    copy: "A defined scope with a clear finish line: a rebrand, a launch, a website, an automation build.",
    fit: "Best for: new brands, relaunches, one big push",
  },
  {
    name: "Retainers",
    copy: "An embedded creative and performance team that ships, tests and improves every week.",
    fit: "Best for: ongoing growth, paid media, content",
  },
  {
    name: "Advisory",
    copy: "Senior strategic guidance for in-house teams who want an outside brain and an honest opinion.",
    fit: "Best for: founders, marketing leads, fractional CMO",
  },
];

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Services"
        title={["What we", "*do.*"]}
        intro={
          <p>
            Five disciplines, one team, zero hand-off drama. We combine strategy, creative and performance so the idea and
            the results are designed together from day one.
          </p>
        }
        aside={
          <nav aria-label="Jump to service">
            <ul className="space-y-2 text-[0.95rem]">
              {services.map((s, i) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="group flex items-center gap-3 text-paper/70 hover:text-paper">
                    <span className="font-display text-xs text-vermilion">0{i + 1}</span>
                    <span className="transition-transform duration-300 group-hover:translate-x-1">{s.name}</span>
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        }
      />

      <div className="bg-paper text-ink">
        {services.map((s, i) => (
          <section
            key={s.id}
            id={s.id}
            className="gutter scroll-mt-20 border-b border-ink/12 py-20 md:py-32"
            aria-labelledby={`${s.id}-title`}
          >
            <div className="grid gap-12 md:grid-cols-12">
              <div className="md:col-span-5">
                <div className="md:sticky md:top-28">
                  <span
                    aria-hidden="true"
                    className="block font-display text-[clamp(5rem,12vw,11rem)] leading-[0.8] font-bold tracking-[-0.04em] text-transparent [-webkit-text-stroke:1.5px_var(--color-vermilion)]"
                  >
                    0{i + 1}
                  </span>
                  <h2 id={`${s.id}-title`} className="text-headline mt-6">
                    {s.name}
                  </h2>
                </div>
              </div>
              <div className="md:col-span-6 md:col-start-7">
                <Reveal>
                  <p className="font-display text-[clamp(1.4rem,2.2vw,2rem)] leading-[1.2] font-medium tracking-[-0.02em]">
                    {s.short}
                  </p>
                  <p className="text-lede mt-6 opacity-75">{s.description}</p>
                </Reveal>
                <Reveal className="mt-12" delay={0.1}>
                  <p className="text-eyebrow mb-4 opacity-60">What you get</p>
                  <ul className="border-t border-ink/15">
                    {s.deliverables.map((d) => (
                      <li key={d} className="flex items-center justify-between gap-6 border-b border-ink/15 py-4 text-[1.05rem]">
                        {d}
                        <span aria-hidden="true" className="h-1.5 w-1.5 shrink-0 rounded-full bg-vermilion" />
                      </li>
                    ))}
                  </ul>
                </Reveal>
                <Reveal className="mt-10 flex gap-4 rounded-[3px] bg-ink p-6 text-paper" delay={0.15}>
                  <span className="text-eyebrow shrink-0 pt-1 text-vermilion">We measure</span>
                  <p className="text-[1.02rem] leading-relaxed text-paper/85">{s.measure}</p>
                </Reveal>
              </div>
            </div>
          </section>
        ))}
      </div>

      <section className="bg-paper-2 text-ink" aria-labelledby="models-title">
        <div className="gutter section-y">
          <SectionLabel index="06" className="mb-8">
            Ways to work together
          </SectionLabel>
          <h2 id="models-title" className="text-display mb-16 max-w-[12ch] md:mb-24">
            Pick your <span className="text-vermilion">pace.</span>
          </h2>
          <ul className="border-t border-ink/15">
            {models.map((m) => (
              <li key={m.name} className="group grid gap-4 border-b border-ink/15 py-8 md:grid-cols-12 md:items-baseline md:py-12">
                <p className="font-display text-[clamp(2.5rem,5vw,4.5rem)] leading-none font-bold tracking-[-0.045em] transition-colors group-hover:text-vermilion md:col-span-5">
                  {m.name}
                </p>
                <p className="text-lede md:col-span-4">{m.copy}</p>
                <p className="text-sm text-ink/55 md:col-span-3 md:text-right">{m.fit}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <Process index="07" />
      <ContactCTA />
    </>
  );
}
