import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { Reveal, SplitText } from "@/components/Reveal";
import { PlaceholderTag, SectionLabel } from "@/components/ui";
import { HalfWord, LogoMark } from "@/components/Logo";
import { ContactCTA } from "@/components/ContactCTA";
import { principles } from "@/lib/content";

export const metadata: Metadata = {
  title: "About",
  description:
    "Halfway Famous is an independent creative and performance marketing agency built on one belief: ordinary gets ignored.",
  alternates: { canonical: "/about" },
};

const team = [
  {
    name: "Lance Duffin",
    role: "Founder",
    bio: "15+ years across marketing, funnels, customer success and e-commerce. Builds brands and growth systems, and has the scars to prove which ones work.",
  },
  { name: "[Team member]", role: "[Role]", bio: "[Short, human bio. One or two sentences.]" },
  { name: "[Team member]", role: "[Role]", bio: "[Short, human bio. One or two sentences.]" },
  { name: "[Team member]", role: "[Role]", bio: "[Short, human bio. One or two sentences.]" },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About"
        title={["Further than", "*most.*"]}
        intro={
          <p>
            Halfway Famous is an independent creative and performance agency. We exist because too much good work goes
            unnoticed, and too much noticed work isn&apos;t any good.
          </p>
        }
      />

      {/* Story */}
      <section className="bg-paper text-ink" aria-labelledby="story-title">
        <div className="gutter section-y grid gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <SectionLabel index="01">Why we exist</SectionLabel>
          </div>
          <div className="md:col-span-8">
            <div id="story-title">
              <SplitText
                as="h2"
                lines={["Creative agencies make", "it beautiful. Performance", "agencies make it work.", "We refuse to *choose.*"]}
                className="text-headline"
              />
            </div>
            <Reveal className="mt-14 grid gap-8 md:grid-cols-2" delay={0.1}>
              <p className="text-lede opacity-75">
                Most companies end up hiring two kinds of partner: one that makes things look good and one that makes the
                numbers move. They rarely talk, and it shows.
              </p>
              <p className="text-lede opacity-75">
                We built Halfway Famous to close that gap: strategists, designers, writers, media buyers and builders on
                one team, measured by one thing. Did it matter?
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* The name / mark */}
      <section className="grain relative overflow-hidden bg-ink text-paper" aria-labelledby="mark-title">
        <div className="gutter section-y relative z-[3] grid items-center gap-16 md:grid-cols-12">
          <Reveal className="flex flex-col items-center gap-10 md:col-span-5">
            <LogoMark className="h-48 w-48 md:h-64 md:w-64" title="Halfway Famous mark" />
            <HalfWord className="text-5xl md:text-6xl" />
          </Reveal>
          <div className="md:col-span-6 md:col-start-7">
            <SectionLabel index="02" className="mb-8 text-ash">
              The mark
            </SectionLabel>
            <h2 id="mark-title" className="text-headline">
              Two halves. <span className="text-vermilion">One backwards F.</span> Both on purpose.
            </h2>
            <Reveal className="mt-10 space-y-6" delay={0.1}>
              <p className="text-lede text-paper/75">
                Our mark is a whole split in two: the thinking and the making, the idea and the numbers. Neither half is
                worth much on its own.
              </p>
              <p className="text-lede text-paper/75">
                And the F faces the wrong way because that&apos;s usually where the interesting answer is. We look at the
                brief from the other side before we write a word.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Principles */}
      <section className="bg-paper text-ink" aria-labelledby="principles-title">
        <div className="gutter section-y">
          <SectionLabel index="03" className="mb-8">
            Principles
          </SectionLabel>
          <h2 id="principles-title" className="text-display mb-16 md:mb-24">
            House <span className="text-vermilion">rules.</span>
          </h2>
          <ol className="border-t border-ink/15">
            {principles.map((p, i) => (
              <li key={p.title} className="group border-b border-ink/15">
                <Reveal className="grid gap-4 py-8 md:grid-cols-12 md:items-baseline md:py-12">
                  <span className="font-display text-sm text-vermilion md:col-span-1">0{i + 1}</span>
                  <p className="font-display text-[clamp(2rem,4.6vw,4.25rem)] leading-[0.98] font-bold tracking-[-0.045em] transition-transform duration-700 ease-[var(--ease-expo)] md:col-span-7 md:group-hover:translate-x-4">
                    {p.title}
                  </p>
                  <p className="text-[1.05rem] leading-relaxed opacity-70 md:col-span-4">{p.copy}</p>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Team */}
      <section className="bg-paper-2 text-ink" aria-labelledby="team-title">
        <div className="gutter section-y">
          <div className="mb-16 flex flex-wrap items-end justify-between gap-6 md:mb-20">
            <div>
              <SectionLabel index="04" className="mb-8">
                People
              </SectionLabel>
              <h2 id="team-title" className="text-display">
                The <span className="text-vermilion">humans.</span>
              </h2>
            </div>
            <PlaceholderTag>Photos & bios pending</PlaceholderTag>
          </div>
          <ul className="grid gap-x-6 gap-y-14 sm:grid-cols-2 lg:grid-cols-4">
            {team.map((m, i) => (
              <li key={i} className={i % 2 === 1 ? "lg:mt-20" : undefined}>
                <Reveal delay={i * 0.06}>
                  <div className="group relative aspect-[4/5] overflow-hidden rounded-[3px] bg-ink">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <LogoMark className="h-16 w-16 text-paper/10 transition-transform duration-700 group-hover:scale-110" />
                    </div>
                    <span className="text-eyebrow absolute bottom-4 left-4 text-paper/40">Portrait placeholder</span>
                  </div>
                  <p className="text-title mt-5">{m.name}</p>
                  <p className="text-eyebrow mt-2 text-vermilion">{m.role}</p>
                  <p className="mt-4 text-[0.98rem] leading-relaxed opacity-70">{m.bio}</p>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <ContactCTA lines={["COME BE", "HALFWAY *FAMOUS.*"]} />
    </>
  );
}
