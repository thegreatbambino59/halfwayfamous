import { NextResponse } from "next/server";

/**
 * Contact form endpoint.
 * Validates input and logs it. To deliver enquiries, connect an email/CRM provider below
 * (e.g. Resend, Postmark, HubSpot or a Slack webhook) using environment variables.
 */
type Payload = {
  name?: string;
  email?: string;
  company?: string;
  website?: string;
  message?: string;
  services?: string[];
  budget?: string;
  hp?: string;
};

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(req: Request) {
  let body: Payload;
  try {
    body = (await req.json()) as Payload;
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request." }, { status: 400 });
  }

  // Honeypot: silently accept bots
  if (body.hp) return NextResponse.json({ ok: true });

  const name = (body.name ?? "").trim();
  const email = (body.email ?? "").trim();
  const message = (body.message ?? "").trim();

  if (!name || !email || !message) {
    return NextResponse.json({ ok: false, error: "Please fill in your name, email and message." }, { status: 422 });
  }
  if (!EMAIL.test(email)) {
    return NextResponse.json({ ok: false, error: "That email address doesn't look right." }, { status: 422 });
  }
  if (message.length > 5000) {
    return NextResponse.json({ ok: false, error: "Message is too long." }, { status: 422 });
  }

  const enquiry = {
    name,
    email,
    company: body.company?.slice(0, 200),
    website: body.website?.slice(0, 300),
    services: (body.services ?? []).slice(0, 10),
    budget: body.budget,
    message,
    receivedAt: new Date().toISOString(),
  };

  // TODO: deliver the enquiry. Example with a webhook:
  // if (process.env.CONTACT_WEBHOOK_URL) {
  //   await fetch(process.env.CONTACT_WEBHOOK_URL, { method: "POST", body: JSON.stringify(enquiry) });
  // }
  console.info("[contact] new enquiry", enquiry);

  return NextResponse.json({ ok: true });
}
