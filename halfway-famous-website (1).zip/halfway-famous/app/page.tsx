import { Hero } from "@/components/home/Hero";
import { Manifesto } from "@/components/home/Manifesto";
import { FeaturedWork } from "@/components/home/FeaturedWork";
import { ServicesList } from "@/components/home/ServicesList";
import { Philosophy } from "@/components/home/Philosophy";
import { Process } from "@/components/home/Process";
import { Credibility } from "@/components/home/Credibility";
import { ContactCTA } from "@/components/ContactCTA";

export default function HomePage() {
  return (
    <>
      <Hero />
      <Manifesto />
      <FeaturedWork />
      <ServicesList />
      <Philosophy />
      <Process />
      <Credibility />
      <ContactCTA />
    </>
  );
}
