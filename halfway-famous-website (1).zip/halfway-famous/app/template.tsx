"use client";

import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { LogoMark } from "@/components/Logo";

/**
 * Page transition: re-mounts on every navigation.
 * A short vermilion curtain lifts away on route changes (skipped on first load so content paints immediately).
 */
let hasNavigated = false;

export default function Template({ children }: { children: React.ReactNode }) {
  const [showCurtain] = useState(() => hasNavigated);
  useEffect(() => {
    hasNavigated = true;
  }, []);

  return (
    <>
      {showCurtain && (
        <motion.div
          aria-hidden="true"
          className="pointer-events-none fixed inset-0 z-[70] flex items-center justify-center bg-vermilion"
          initial={{ clipPath: "inset(0 0 0% 0)" }}
          animate={{ clipPath: "inset(0 0 100% 0)" }}
          transition={{ duration: 0.75, ease: [0.76, 0, 0.24, 1], delay: 0.1 }}
        >
          <LogoMark className="h-14 w-14 text-ink" />
        </motion.div>
      )}
      <motion.div
        initial={showCurtain ? { opacity: 0, y: 24 } : false}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: showCurtain ? 0.35 : 0 }}
      >
        {children}
      </motion.div>
    </>
  );
}
