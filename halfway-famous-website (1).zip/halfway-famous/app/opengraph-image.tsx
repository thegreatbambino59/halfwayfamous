import { ImageResponse } from "next/og";
import { MARK_D } from "@/lib/mark";

export const dynamic = "force-static";

export const alt = "Halfway Famous — Ordinary gets ignored.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OgImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: "#111111",
          color: "#F2F0EA",
          padding: 72,
          position: "relative",
        }}
      >
        <div style={{ display: "flex", position: "absolute", right: 120, top: 120, width: 360, height: 180, borderRadius: "180px 180px 0 0", border: "2px solid #F2F0EA" }} />
        <div style={{ display: "flex", position: "absolute", right: 150, top: 304, width: 360, height: 180, borderRadius: "0 0 180px 180px", background: "#E44632" }} />
        <div style={{ display: "flex", position: "absolute", left: 0, right: 0, top: 302, height: 2, background: "rgba(242,240,234,0.35)" }} />
        <svg width="64" height="64" viewBox="0 0 274 274">
          <path d={MARK_D} fill="#F2F0EA" fillRule="evenodd" />
        </svg>
        <div style={{ display: "flex", flexDirection: "column", fontSize: 110, fontWeight: 700, letterSpacing: -5, lineHeight: 0.9 }}>
          <span>ORDINARY</span>
          <span>GETS IGNORED<span style={{ color: "#E44632" }}>.</span></span>
        </div>
      </div>
    ),
    size,
  );
}
