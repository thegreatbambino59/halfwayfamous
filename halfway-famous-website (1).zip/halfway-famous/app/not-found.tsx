import { ButtonLink } from "@/components/ui";

export default function NotFound() {
  return (
    <section className="grain relative flex min-h-[100svh] items-end overflow-hidden bg-ink pb-16 text-paper">
      <div className="gutter relative z-[3] w-full">
        <p className="text-eyebrow mb-8 text-ash">Error 404</p>
        <h1 className="text-mega">
          Halfway
          <br />
          to <span className="text-vermilion">nowhere.</span>
        </h1>
        <div className="mt-12 flex flex-wrap items-center gap-6">
          <p className="text-lede max-w-md text-paper/75">This page doesn&apos;t exist. The rest of the site does, and it&apos;s much better.</p>
          <ButtonLink href="/">Back to the homepage</ButtonLink>
        </div>
      </div>
    </section>
  );
}
