import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Providers } from "@/components/Providers";
import { site } from "@/lib/content";

// Self-hosted static font instances (SIL Open Font License) — no runtime dependency on Google Fonts.
// Static cuts are used instead of variable files to avoid contour-overlap seams at very large display sizes.
const display = localFont({
  src: [
    { path: "./fonts/SpaceGrotesk-400.woff2", weight: "400" },
    { path: "./fonts/SpaceGrotesk-500.woff2", weight: "500" },
    { path: "./fonts/SpaceGrotesk-600.woff2", weight: "600" },
    { path: "./fonts/SpaceGrotesk-700.woff2", weight: "700" },
  ],
  variable: "--font-space-grotesk",
  display: "swap",
});
const sans = localFont({
  src: [
    { path: "./fonts/Inter-400.woff2", weight: "400" },
    { path: "./fonts/Inter-500.woff2", weight: "500" },
    { path: "./fonts/Inter-600.woff2", weight: "600" },
  ],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "Halfway Famous — Ordinary gets ignored.",
    template: "%s — Halfway Famous",
  },
  description: site.description,
  applicationName: site.name,
  keywords: [
    "creative agency",
    "digital marketing agency",
    "brand strategy",
    "performance marketing",
    "web design",
    "AI automation",
  ],
  openGraph: {
    type: "website",
    siteName: site.name,
    title: "Halfway Famous — Ordinary gets ignored.",
    description: site.description,
    url: "/",
  },
  twitter: { card: "summary_large_image" },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = {
  themeColor: "#111111",
  colorScheme: "dark",
};

const orgJsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: site.name,
  url: site.url,
  email: site.email,
  description: site.description,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd) }} />
        <Providers>
          <Header />
          <main id="main">{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
