import type { Metadata } from "next";
import { SplitText, Reveal } from "@/components/Reveal";
import { ContactForm } from "@/components/ContactForm";
import { HorizonRule } from "@/components/HorizonRule";
import { site } from "@/lib/content";

export const metadata: Metadata = {
  title: "Contact",
  description: "Start a project with Halfway Famous. Tell us what you're building.",
  alternates: { canonical: "/contact" },
};

const next = [
  { t: "We read it", d: "A real person reviews every enquiry, usually within two business days." },
  { t: "We talk", d: "A 30-minute call to understand the goal, the constraints and whether we're a fit." },
  { t: "We propose", d: "A clear plan with scope, timeline and investment. No mystery line items." },
];

export default function ContactPage() {
  return (
    <>
      <section className="grain relative overflow-hidden bg-ink pt-36 pb-16 text-paper md:pt-48 md:pb-24">
        <div className="gutter relative z-[3]">
          <p className="text-eyebrow mb-8 flex items-center gap-3 text-ash md:mb-12">
            <span className="rec-dot h-2 w-2 rounded-full bg-vermilion" aria-hidden="true" />
            Now booking new projects
          </p>
          <SplitText as="h1" lines={["Let's make", "something", "*happen.*"]} className="text-mega" onMount stagger={0.07} />
          <div className="mt-14">
            <HorizonRule />
          </div>
        </div>
      </section>

      <section className="bg-paper text-ink">
        <div className="gutter section-y grid gap-16 md:grid-cols-12">
          <div className="md:col-span-7">
            <ContactForm />
          </div>

          <aside className="space-y-14 md:col-span-4 md:col-start-9">
            <Reveal>
              <p className="text-eyebrow mb-4 opacity-60">Prefer email?</p>
              <a
                href={`mailto:${site.email}`}
                className="font-display text-2xl font-medium break-all underline decoration-vermilion decoration-2 underline-offset-[6px] hover:text-vermilion"
              >
                {site.email}
              </a>
            </Reveal>
            <Reveal delay={0.05}>
              <p className="text-eyebrow mb-4 opacity-60">Call</p>
              <p className="font-display text-xl">{site.phone}</p>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="text-eyebrow mb-4 opacity-60">Based in</p>
              <p className="font-display text-xl">{site.location}</p>
              <p className="mt-1 text-sm opacity-60">Working with brands everywhere.</p>
            </Reveal>
            <Reveal delay={0.15}>
              <p className="text-eyebrow mb-6 opacity-60">What happens next</p>
              <ol className="border-t border-ink/15">
                {next.map((n, i) => (
                  <li key={n.t} className="flex gap-5 border-b border-ink/15 py-5">
                    <span className="font-display text-sm text-vermilion">0{i + 1}</span>
                    <div>
                      <p className="font-display text-lg font-semibold">{n.t}</p>
                      <p className="mt-1 text-[0.95rem] leading-relaxed opacity-70">{n.d}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </Reveal>
            <Reveal delay={0.2}>
              <p className="text-eyebrow mb-4 opacity-60">Elsewhere</p>
              <ul className="flex flex-wrap gap-x-6 gap-y-2">
                {site.social.map((s) => (
                  <li key={s.label}>
                    <a href={s.href} className="font-display font-medium hover:text-vermilion">
                      {s.label}
                    </a>
                  </li>
                ))}
              </ul>
            </Reveal>
          </aside>
        </div>
      </section>
    </>
  );
}
