import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { PlaceholderTag } from "@/components/ui";
import { site } from "@/lib/content";

export const metadata: Metadata = {
  title: "Privacy",
  description: "How Halfway Famous handles personal information.",
  alternates: { canonical: "/privacy" },
  robots: { index: false },
};

export default function PrivacyPage() {
  return (
    <>
      <PageHero eyebrow="Legal" title={["Privacy."]} />
      <section className="bg-paper text-ink">
        <div className="gutter section-y max-w-3xl space-y-6 text-[1.08rem] leading-[1.75] text-ink/80">
          <PlaceholderTag>Placeholder — have this reviewed by counsel before launch</PlaceholderTag>
          <p>
            This page should describe what personal information Halfway Famous collects (for example, details submitted
            through the contact form), why it is collected, how long it is kept, which service providers process it,
            and how people can request access or deletion.
          </p>
          <p>
            If analytics, advertising pixels or cookies are added to this site, list them here and add a consent
            mechanism where required.
          </p>
          <p>
            Questions: <a className="underline" href={`mailto:${site.email}`}>{site.email}</a>
          </p>
        </div>
      </section>
    </>
  );
}
