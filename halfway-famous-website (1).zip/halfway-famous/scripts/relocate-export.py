"""Make a Next.js static export (`out/`) work from any sub-path: relative asset/page URLs + runtime public path.
Usage: python3 scripts/relocate-export.py out/   (used for the claude.ai preview build)"""
import os, re, sys
root = sys.argv[1]
for dp, _, fn in os.walk(root):
    for f in fn:
        p = os.path.join(dp, f)
        if f.endswith(".txt") and f != "robots.txt":
            os.remove(p); continue
        if f.endswith(".html"):
            depth = len(os.path.relpath(p, root).split(os.sep)) - 1
            rel = "../" * depth or "./"
            s = open(p, encoding="utf-8").read().replace("/_next/", rel + "_next/")
            s = s.replace('href="/icon.svg', 'href="' + rel + "icon.svg")
            s = re.sub(r'href="(/(?!/)[a-z0-9\-/]*)(#[a-z0-9\-]*)?"',
                       lambda m: 'href="' + rel + (m.group(1).strip("/") + "/" if m.group(1).strip("/") else "") + "index.html" + (m.group(2) or "") + '"', s)
            s = s.replace("<head>", '<head><script>self.__HF_BASE__=new URL("' + rel + '",location.href).pathname;</script>', 1)
            open(p, "w", encoding="utf-8").write(s)
        elif f.endswith(".css"):
            s = open(p).read().replace("/_next/static/media/", "../media/"); open(p, "w").write(s)
        elif f.endswith(".js"):
            s = open(p).read()
            if '.p="/_next/"' in s:
                open(p, "w").write(s.replace('.p="/_next/"', '.p=(self.__HF_BASE__||"/")+"_next/"'))
