# Halfway Famous — Design System

## Concept: "The Horizon"

The logo is a whole split into two halves. The site turns that split into its core image: **a sun cut in half by a horizon line**. Halfway risen, halfway set. It shows up as the hero visual, the horizon rule under every page title, the strike-through lines in the Philosophy section and the half-shapes in the placeholder art. The mirrored **ꟻ** from the wordmark appears only in the brand lockups.

Tone: editorial, high-contrast, cinematic (film grain, running timecode), typographically led. Images are scarce, so each one is large.

## Color

| Token              | Hex       | Use |
| ------------------ | --------- | --- |
| `ink`              | `#111111` | Primary dark surfaces, body text on light |
| `paper`            | `#F2F0EA` | Primary light surfaces, text on dark |
| `paper-2`          | `#E7E4DB` | Secondary light surface (team, engagement models) |
| `vermilion`        | `#E44632` | The single accent: CTAs, emphasis words, markers, the CTA band |
| `vermilion-deep`   | `#C23824` | Error text on light surfaces |
| `ash`              | `#A7A79F` | Muted labels, meta, struck-through words |
| `white`            | `#FFFFFF` | Text on vermilion buttons |

Rules: vermilion is used **sparingly**, once or twice per viewport. Sections alternate **ink ↔ paper** to create rhythm. The vermilion full-bleed band is reserved for the closing CTA.

## Typography

| Utility        | Font            | Size (fluid)            | Leading | Tracking |
| -------------- | --------------- | ----------------------- | ------- | -------- |
| `text-mega`    | Space Grotesk 700 | 3.4rem → 15rem (13.5vw) | 0.84 | −0.035em |
| `text-display` | Space Grotesk 700 | 2.75rem → 8.5rem (8vw) | 0.90 | −0.045em |
| `text-headline`| Space Grotesk 600 | 2rem → 4.75rem | 0.98 | −0.035em |
| `text-title`   | Space Grotesk 600 | 1.5rem → 2.4rem | 1.08 | −0.025em |
| `text-lede`    | Inter 400         | 1.125rem → 1.4rem | 1.5 | −0.01em |
| body           | Inter 400         | ~1rem–1.15rem | 1.5–1.75 | 0 |
| `text-eyebrow` | Space Grotesk 500 | 0.75rem, uppercase | 1 | +0.16em |

- Headlines: short, punchy, often ending in a vermilion period or a vermilion final word (`*word*` in `SplitText`).
- Section labels are numbered: `(02) Selected work ——`.
- Fonts are self-hosted from `app/fonts` (SIL OFL).

## Layout & spacing

- **Grid:** 12 columns on desktop, single column on mobile. Asymmetric placement is preferred (8/4, 7/5, offset starts).
- **Gutter:** `gutter` utility = `clamp(1rem, 4vw, 3.5rem)` horizontal padding (16px minimum on phones).
- **Section rhythm:** `section-y` = `clamp(5rem, 12vw, 11rem)` vertical padding.
- **Dividers:** 1px hairlines at 10–15% opacity of the current text color; no boxes or cards.
- **Radius:** essentially square (3px) on imagery; fully round only on pills and buttons.

## Motion

| Pattern | Where | Spec |
|---|---|---|
| Masked word reveal | All headlines (`SplitText`) | y 110% → 0, rotate 4° → 0, 1.05s, expo-out `cubic-bezier(.16,1,.3,1)`, 60ms stagger |
| Fade-rise | Body blocks (`Reveal`) | opacity 0 → 1, y 36 → 0, 1.1s expo-out |
| Scroll-linked | Manifesto word illumination, dark→light handoff, Process outline→fill, image scale 1.18 → 1 | `useScroll` + `useTransform` |
| Hover | Buttons (fill rises from below), rows (vermilion wipe, x-shift), images (1.06 zoom + detail panel) | 500–700ms expo |
| Page transition | `app/template.tsx` | vermilion curtain lifts away (0.75s quart) on route change only |
| Ambient | Hero grain, glow drift, timecode, marquee | CSS only, paused/disabled under reduced motion |

Reduced motion: `MotionConfig reducedMotion="user"` removes transforms; CSS shortens all animations.

## Components

| Component | File | Notes |
|---|---|---|
| `Logo`, `LogoMark`, `HalfWord` | `components/Logo.tsx` | Mark is a crisp SVG redraw with transparent cut-outs (`currentColor`). |
| `Header` | `components/Header.tsx` | Transparent → blurred ink on scroll; hides on scroll-down; full-screen mobile menu with focus trap. |
| `Footer` | `components/Footer.tsx` | Nav, services, social, large wordmark signature. |
| `PageHero` | `components/PageHero.tsx` | Eyebrow + mega title + `HorizonRule` + intro/aside. |
| `ContactCTA` | `components/ContactCTA.tsx` | Vermilion closing band; custom lines/copy per page. |
| `ButtonLink` | `components/ui.tsx` | Tones: `vermilion`, `ink`, `paper`, `ghost-light`, `ghost-dark`; sizes `md`, `lg`. |
| `ArrowLink` | `components/ui.tsx` | Underline that retracts on hover. |
| `SectionLabel` | `components/ui.tsx` | `(01) Label ——` |
| `PlaceholderTag` | `components/ui.tsx` | Honest labeling for anything that is not real yet. |
| `Marquee` | `components/ui.tsx` | Infinite CSS marquee, pauses on hover. |
| `SplitText`, `Reveal` | `components/Reveal.tsx` | Motion primitives. |
| `WorkPanel` | `components/WorkPanel.tsx` | Case-study panel with scroll scale + hover reveal; touch shows details below. |
| `ArtPlate` | `components/ArtPlate.tsx` | Six original SVG compositions (`sun`, `topo`, `halves`, `signal`, `grid`, `orbit`). |
| `ServicesList` | `components/home/ServicesList.tsx` | Oversized accordion rows. |

## Imagery direction (for real assets)

- Cinematic, high-contrast photography and film stills; real people doing real work, shot with intent.
- Strong negative space, horizon lines and split compositions echo the brand.
- Avoid: handshakes, laptops-on-desks, generic office meetings, blue/purple gradients and glassmorphism.
